import importlib
import os

# Mapear o que é obrigatório
PAINEIS = {
    "supremo": ("ui.painel_supremo", "painel_supremo"),
    "apple": ("ui.dashboard_apple", "main_dashboard"),
    "quantum": ("ui.dashboard_quantum", "main_dashboard"),
    "dazarabia": ("ui.dashboard_dazarabia", "main_dashboard"),
    "lab": ("ui.dashboard_lab", "main_dashboard"),
    "auditoria": ("ui.painel_auditoria", "painel_auditoria"),
    "config": ("ui.config_advanced", "painel_config_advanced"),
    "risco": ("ui.risk_dashboard", "risk_dashboard"),
    "onboarding": ("ui.onboarding", "exibir_onboarding"),
}
PLUGINS = [
    "plugins.supremo_ia", "plugins.copytrade", "plugins.scalping", "plugins.arbitrage", "plugins.hedge"
]
CORE_FUNCS = [
    ("core.logger_auditoria", "log_event"),
    ("core.binance_exec_supremo", "executar_ordem"),
    ("core.backup_scheduler", "criar_backup"),
    ("modules.utils", "ler_logs_rapidos"),
]
ARCHIVOS_CRITICOS = [
    "requirements.txt", ".env", "app.py", "3eye_selector.bat"
]

def checar_import(modulo, funcao=None):
    try:
        m = importlib.import_module(modulo)
        if funcao:
            assert hasattr(m, funcao)
        return True, ""
    except Exception as e:
        return False, str(e)

def checar_arquivo_existe(caminho):
    return os.path.exists(caminho)

def main():
    print("========== VALIDADOR DE INTEGRAÇÃO 3EYE SUPREMO ==========")
    print("\n> Verificando PAINEIS:")
    for nome, (mod, func) in PAINEIS.items():
        ok, erro = checar_import(mod, func)
        print(f"  {'[OK]' if ok else '[FALHA]'} {mod}.{func}" + ("" if ok else f" — {erro}"))
    print("\n> Verificando PLUGINS:")
    for plug in PLUGINS:
        ok, erro = checar_import(plug, "executar")
        print(f"  {'[OK]' if ok else '[FALHA]'} {plug}.executar" + ("" if ok else f" — {erro}"))
    print("\n> Verificando CORE:")
    for mod, func in CORE_FUNCS:
        ok, erro = checar_import(mod, func)
        print(f"  {'[OK]' if ok else '[FALHA]'} {mod}.{func}" + ("" if ok else f" — {erro}"))
    print("\n> Verificando arquivos críticos:")
    for f in ARCHIVOS_CRITICOS:
        ok = checar_arquivo_existe(f)
        print(f"  {'[OK]' if ok else '[FALHA]'} {f}")
    print("\n========== FIM DA VALIDAÇÃO ==========\n")

if __name__ == "__main__":
    main()
