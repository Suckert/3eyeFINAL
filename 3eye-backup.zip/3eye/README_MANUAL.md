# README_MANUAL.md - arquivo de sistema 3eye
