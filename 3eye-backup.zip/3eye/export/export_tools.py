import pandas as pd
import os
from fpdf import FPDF
from core.logger_auditoria import log_event

def exportar_historico_excel(df, caminho="export/historico_export.xlsx"):
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    df.to_excel(caminho, index=True)
    log_event(f"Histórico exportado para Excel: {caminho}")
    return caminho

def exportar_historico_pdf(df, caminho="export/historico_export.pdf"):
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=8)
    pdf.cell(200, 10, txt="Histórico de Resultados 3EYE SUPREMO", ln=True, align='C')
    # Cabeçalhos
    for col in df.columns:
        pdf.cell(30, 10, col, 1, 0, 'C')
    pdf.ln()
    # Linhas
    for i, row in df.iterrows():
        for val in row:
            pdf.cell(30, 10, str(val), 1, 0, 'C')
        pdf.ln()
    pdf.output(caminho)
    log_event(f"Histórico exportado para PDF: {caminho}")
    return caminho
