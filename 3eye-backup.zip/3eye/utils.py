import os
import glob
import importlib
import pandas as pd
import json
import datetime

# --- Plug-ins dinâmicos ---
def listar_plugins():
    plugins = []
    if os.path.exists("plugins"):
        for f in glob.glob("plugins/*.py"):
            if not f.endswith("__init__.py"):
                plugins.append(os.path.basename(f)[:-3])
    return plugins

def executar_plugin(nome, **kwargs):
    try:
        mod = importlib.import_module(f"plugins.{nome}")
        if hasattr(mod, "run"):
            return mod.run(**kwargs)
        else:
            return f"Plugin {nome} não possui função run()"
    except Exception as e:
        return f"Erro no plug-in {nome}: {e}"

# --- Backup manual ---
def trigger_backup_manual():
    from core.backup_module import BackupManager
    backup = BackupManager()
    if backup.executar_backup():
        return True
    return False

# --- Exportação Excel ---
def exportar_operacoes_excel():
    from core.logger_auditoria import get_audit_log
    df = get_audit_log()
    arquivo = f"operacoes_{datetime.date.today()}.xlsx"
    df.to_excel(arquivo, index=False)
    return arquivo

# --- Importação de Configuração ---
def importar_configuracao():
    from config_manager import ConfigManager
    config = ConfigManager()
    import_file = "config_import.json"
    if os.path.exists(import_file):
        config.importar(import_file)
        return True
    return False

# --- Reset do Sistema ---
def resetar_sistema():
    # Limpa arquivos críticos (logs, backups, configs). Cuidado: use apenas sob demanda!
    for pasta in ["logs", "backup"]:
        if os.path.exists(pasta):
            for f in glob.glob(f"{pasta}/*"):
                if os.path.isdir(f):
                    for ff in glob.glob(f"{f}/*"):
                        os.remove(ff)
                    os.rmdir(f)
                else:
                    os.remove(f)
    for f in ["config.json", "carteira_export.csv"]:
        if os.path.exists(f):
            os.remove(f)
    return True

# --- Execução de Trades (manual) ---
def executar_trade(side):
    # Integração real com Binance ou simulação, usando core.binance_exec_supremo
    from core.binance_exec_supremo import BinanceExecutor
    from dotenv import load_dotenv
    load_dotenv()
    executor = BinanceExecutor(os.getenv("API_KEY_BINANCE"), os.getenv("SECRET_KEY_BINANCE"))
    par = "BTC/USDT"  # Ou selecione dinamicamente
    amount = 0.01
    if side == "buy":
        executor.executar_ordem(par, "buy", amount)
    elif side == "sell":
        executor.executar_ordem(par, "sell", amount)
    return True

# --- Rebalanceamento Inteligente ---
def executar_rebalanceamento():
    from modules.rebalanceador_supremo import Rebalanceador
    from core.portfolio_manager import PortfolioManager
    rebalance = Rebalanceador()
    carteira = PortfolioManager(None)  # Conecte ao executor real
    perfil = st.session_state.get("perfil", "Moderado")
    regime = "bull"
    # Aqui você deve passar dados reais!
    score_ativos = {"BTC": 0.4, "ETH": 0.3, "BNB": 0.3}
    aloc = rebalance.calcular_alocacao(perfil, regime, score_ativos)
    rebalance.rebalancear(carteira.carteira, aloc, None)
    return True

# --- Execução IA Auto (todo ciclo) ---
def executar_ia_auto():
    from modules.ml_supremo import MLTrader
    ml = MLTrader()
    # Exemplo: usar sinais históricos/atuais
    X = [[0.4, 0.7, 0.2]]  # Features reais devem ser passadas!
    resultado = ml.prever(X)
    return resultado

# --- Logs e Alertas Rápidos ---
def ler_logs_rapidos():
    from core.logger_auditoria import get_audit_log
    df = get_audit_log()
    if df is not None and not df.empty:
        return [f"{row['timestamp']} | {row['acao']}" for idx, row in df.tail(4).iterrows()]
    return []

# --- Último Trade ---
def ler_ultimo_trade():
    from core.logger_auditoria import get_audit_log
    df = get_audit_log()
    if df is not None and not df.empty:
        ult = df[df['acao'].str.contains('trade|ordem|exec', case=False, na=False)].tail(1)
        if not ult.empty:
            return f"{ult.iloc[0].get('timestamp', '')}: {ult.iloc[0].get('acao', '')}"
    return "Sem trades recentes"

# --- Status Dinâmicos e KPIs ---
def get_status_ia():
    # Leia status real da IA do sistema (pode ser um arquivo, variável, health check, etc)
    return "🟢 Ativa"

def get_status_risco():
    # Lógica real de risco
    return "Moderado"

def get_sharpe():
    # Calcule Sharpe real ou simulado
    return 1.15

def get_drawdown():
    return -3.5

def get_saldo():
    # Exemplo: ler carteira/capital real
    return 15700.0

def get_objetivo():
    return 1000.0

# --- Atualização global de variáveis de sessão (real time) ---
def atualizar_variaveis_sessao():
    for k in ['perfil', 'alavancagem', 'objetivo', 'ia_auto', 'tema', 'saldo', 'lucro_acumulado', 'lucro_hist', 'saldo_hist', 'alerta', 'noticia_macro']:
        if k not in st.session_state:
            st.session_state[k] = None
