import streamlit as st
from ui.side_menu import side_menu
from ui.charts import kpi_cards, multi_coin_chart, heatmap_score, capital_chart, timeline, custom_css
from core.logger_auditoria import get_audit_log
from utils import listar_plugins, executar_plugin
from ui.side_menu import super_sidebar
super_sidebar()

def main_painel(**managers):
    custom_css()
    menu = side_menu(
        ["Overview", "Copy Trading", "3eye Vision", "Performance", "Macros/Plug-ins", "Alertas", "Logs", "Configuração"],
        "Overview", logo_path="3eye-logo-v2.png"
    )

    if menu == "Overview":
        st.markdown('<div class="main-title">3EYE Quantum Cyber — Futurist Trading Arena</div>', unsafe_allow_html=True)
        kpi_cards([
            {"label": "Lucro 24h", "valor": "R$1.720", "delta": "+3.2%"},
            {"label": "Retorno (%)", "valor": "+41.2%"},
            {"label": "Top Signal", "valor": "BTC/USDT"},
            {"label": "Volatilidade", "valor": "Alta"}
        ])

    if menu == "Copy Trading":
        st.title("Copy Trading & Ranking de Top Traders")
        st.write("Painel para seguir, comparar e analisar performance dos melhores traders.")

    if menu == "3eye Vision":
        st.title("Vision: Ativos Multi-Gráfico")
        multi_coin_chart(managers.get("dados_candles", {}), managers.get("dados_indicadores", {}))
        heatmap_score(managers.get("score", {"BTC": 0.7, "ETH": 0.5, "ADA": -0.3}))

    if menu == "Performance":
        st.title("Performance Avançada")
        if hasattr(managers["carteira"], "carteira"):
            capital_chart(managers["carteira"].carteira)
        st.dataframe(managers["carteira"].carteira)

    if menu == "Macros/Plug-ins":
        st.title("Macros, Plug-ins e Estratégias Quantum")
        plugins = listar_plugins()
        escolha = st.selectbox("Escolha um Plug-in", plugins)
        if st.button("Executar Plug-in"):
            resultado = executar_plugin(escolha, carteira=managers["carteira"], mercado=managers.get("mercado", {}))
            st.json(resultado)

    if menu == "Alertas":
        st.title("Alertas Inteligentes")
        st.warning("Exemplo: Stop automático ativado para BTC/USDT. Sinal IA de volatilidade detectado.")

    if menu == "Logs":
        st.title("Logs e Auditoria Quantum")
        st.dataframe(get_audit_log(), use_container_width=True)

    if menu == "Configuração":
        st.title("Configuração do Painel Quantum Cyber")
        st.json(managers["config"].config)
