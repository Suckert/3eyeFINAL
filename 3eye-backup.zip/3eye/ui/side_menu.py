import streamlit as st
from datetime import datetime
from utils import (
    listar_plugins, executar_plugin, 
    trigger_backup_manual, exportar_operacoes_excel, importar_configuracao, 
    resetar_sistema, executar_trade, executar_rebalanceamento, 
    executar_ia_auto, ler_logs_rapidos, ler_ultimo_trade, get_status_ia, 
    get_status_risco, get_sharpe, get_drawdown, get_saldo, 
    atualizar_variaveis_sessao, get_plugin_history
)
from core.logger_auditoria import log_event

def super_sidebar():
    atualizar_variaveis_sessao()
    st.sidebar.image("3eye-logo-v2.png", width=120)
    st.sidebar.markdown("### <span style='color:#FFD700;'>3EYE SUPREMO</span>", unsafe_allow_html=True)
    st.sidebar.markdown("---")

    # PERFIL DE OPERAÇÃO
    st.sidebar.subheader("🔰 Perfil de Operação")
    perfis = ["Conservador", "Moderado", "Agressivo", "IA Inteligente", "SUPREMO IA-Alavancada"]
    perfil = st.sidebar.selectbox("Perfil:", perfis, index=st.session_state.get("perfil_index", 4))
    st.session_state['perfil'] = perfil
    st.session_state['perfil_index'] = perfis.index(perfil)
    alavancagem = st.sidebar.slider("Alavancagem (IA ajusta)", 1, 20, st.session_state.get("alavancagem", 5))
    st.session_state['alavancagem'] = alavancagem
    objetivo = st.sidebar.number_input(
        "Objetivo Diário (R$)", min_value=100.0, max_value=1_000_000.0, 
        value=st.session_state.get("objetivo", 2000.0), step=100.0
    )
    st.session_state['objetivo'] = objetivo
    autoexec = st.sidebar.checkbox("Execução Automática IA", value=st.session_state.get("ia_auto", True))
    st.session_state['ia_auto'] = autoexec

    st.sidebar.markdown("---")
    # STATUS DO SISTEMA
    st.sidebar.subheader("⚡ Status do Sistema")
    ia_status = get_status_ia()
    modo_operacao = "Real" if st.session_state.get("modo_real", False) else "Simulado"
    saldo = get_saldo()
    lucro_acum = st.session_state.get("lucro_acumulado", 0)
    drawdown = get_drawdown()
    sharpe = get_sharpe()
    risco = get_status_risco()
    st.sidebar.write(f"IA: **{'🟢' if ia_status == 'ONLINE' else '🔴'} {ia_status}**")
    st.sidebar.write(f"Modo: **{modo_operacao}**")
    st.sidebar.write(f"Saldo: **R$ {saldo:,.2f}**")
    st.sidebar.write(f"Lucro Total: **R$ {lucro_acum:,.2f}**")
    st.sidebar.write(f"Drawdown: **{drawdown}%**")
    st.sidebar.write(f"Sharpe: **{sharpe}**")
    st.sidebar.write(f"Risco: **{risco}**")

    # PLUGINS PERFORMANCE (minicharts/progress)
    st.sidebar.markdown("### Plug-ins: Última performance")
    plugins = listar_plugins()
    for plug in plugins:
        hist, _ = get_plugin_history(plug)
        if len(hist):
            st.sidebar.progress(hist[-1] / 1000.0 if hist[-1] < 1000 else 1.0, text=plug)
        else:
            st.sidebar.caption(f"{plug}: -")

    st.sidebar.markdown("---")
    # AÇÕES RÁPIDAS
    st.sidebar.subheader("🎯 Ações Rápidas")
    col1, col2 = st.sidebar.columns(2)
    with col1:
        if st.button("Comprar (Manual)"):
            executar_trade("buy")
            log_event({"acao": "comprar_manual", "perfil": perfil})
        if st.button("Rebalancear Agora"):
            executar_rebalanceamento()
            log_event({"acao": "rebalancear_agora", "perfil": perfil})
        if st.button("Backup Manual"):
            trigger_backup_manual()
    with col2:
        if st.button("Vender (Manual)"):
            executar_trade("sell")
            log_event({"acao": "vender_manual", "perfil": perfil})
        if st.button("Executar IA Agora"):
            executar_ia_auto()
            log_event({"acao": "executar_ia_auto", "perfil": perfil})
        if st.button("Exportar Operações (Excel)"):
            exportar_operacoes_excel()

    st.sidebar.markdown("---")
    # CONFIGURAÇÃO/RESET
    st.sidebar.subheader("🛡️ Backup & Configuração")
    colc1, colc2 = st.sidebar.columns(2)
    with colc1:
        if st.button("Importar Configuração"):
            importar_configuracao()
        if st.button("Resetar Sistema"):
            resetar_sistema()
    
    # ALERTAS, LOGS E INFOS
    st.sidebar.markdown("---")
    st.sidebar.subheader("📡 Alertas & Informações")
    st.sidebar.write(f"Último Trade: **{ler_ultimo_trade()}**")
    st.sidebar.write(f"Alertas: **{st.session_state.get('alerta', 'Nenhum')}**")
    logs_rapidos = ler_logs_rapidos()
    if logs_rapidos:
        st.sidebar.markdown("### Logs Recentes:")
        for log in logs_rapidos[-5:]:
            st.sidebar.caption(log)

    st.sidebar.markdown("---")
    # TEMA E VISUAL
    st.sidebar.subheader("🎨 Tema e Visual")
    temas = ["Apple Vision", "Quantum Cyber", "Dazarabia Lux", "Supreme Lab"]
    tema = st.sidebar.radio("Escolha o Tema:", temas, index=st.session_state.get("tema_index", 0))
    st.session_state['tema'] = tema
    st.session_state['tema_index'] = temas.index(tema)

    st.sidebar.markdown("---")
    # INFORMAÇÃO E SUPORTE
    st.sidebar.subheader("ℹ️ Sobre o Sistema")
    st.sidebar.write("""
    3EYE SUPREMO — IA institucional para trade e gestão de performance.
    - Versão 3.0 SUPREME — Suckert Technologies.
    - Suporte: suporte@3eye.com
    """)
    st.sidebar.write("© 2025 — Todos os direitos reservados.")

    # BÔNUS: DICA BÍBLICA/PHILOSÓFICA DO DIA
    st.sidebar.markdown("---")
    st.sidebar.caption("“Com sabedoria se constrói a casa, com discernimento ela se consolida.” (Provérbios 24:3)")
    st.sidebar.caption("“O autocontrole é o verdadeiro poder.” (Bhagavad Gita)")

# Para usar:
# from ui.side_menu import super_sidebar
# super_sidebar()
