import streamlit as st
from ui.side_menu import side_menu
from ui.charts import kpi_cards, multi_coin_chart, heatmap_score, capital_chart, timeline, custom_css
from core.logger_auditoria import get_audit_log
from utils import listar_plugins, executar_plugin
from ui.side_menu import super_sidebar
super_sidebar()

def main_painel(**managers):
    custom_css()
    menu = side_menu(
        ["Painel do Rei", "Carteira Real", "Sinais Salomão", "Performance Ouro", "Macros/Plug-ins", "Logs do Trono", "Configuração"],
        "Painel do Rei", logo_path="3eye-logo-v2.png"
    )

    if menu == "Painel do Rei":
        st.markdown('<div class="lux-title">👑 3EYE Dazarabia Lux — Painel do Rei</div>', unsafe_allow_html=True)
        kpi_cards([
            {"label": "Saldo Real", "valor": "R$ 17.410", "delta": "+9.5%"},
            {"label": "Ouro", "valor": "2,3 oz"},
            {"label": "Sinais Ativos", "valor": "4"},
            {"label": "Drawdown", "valor": "-2.1%"}
        ])
        if hasattr(managers["carteira"], "carteira") and not managers["carteira"].carteira.empty:
            capital_chart(managers["carteira"].carteira)

    if menu == "Carteira Real":
        st.title("Carteira Real e Evolução")
        st.dataframe(managers["carteira"].carteira)

    if menu == "Sinais Salomão":
        st.title("Sinais do Salomão (IA + Sabedoria)")
        st.write("Exibição de sinais táticos com base em IA, análise fundamentalista e Provérbios.")

    if menu == "Performance Ouro":
        st.title("Performance do Portfólio de Ouro")
        if hasattr(managers["carteira"], "carteira"):
            capital_chart(managers["carteira"].carteira)

    if menu == "Macros/Plug-ins":
        st.title("Macros, Plug-ins & Estratégias do Trono")
        plugins = listar_plugins()
        escolha = st.selectbox("Escolha um Plug-in", plugins)
        if st.button("Executar Plug-in"):
            resultado = executar_plugin(escolha, carteira=managers["carteira"], mercado=managers.get("mercado", {}))
            st.json(resultado)

    if menu == "Logs do Trono":
        st.title("Logs do Trono Real")
        st.dataframe(get_audit_log(), use_container_width=True)

    if menu == "Configuração":
        st.title("Configuração Luxo Dazarabia")
        st.json(managers["config"].config)
