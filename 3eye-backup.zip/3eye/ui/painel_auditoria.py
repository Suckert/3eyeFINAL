import streamlit as st
import json
from datetime import datetime
from ui.side_menu import super_sidebar
super_sidebar()

def painel_auditoria():
    st.title("Painel de Auditoria — 3EYE SUPREMO")
    try:
        with open("data/logs/log_auditoria.txt", "r", encoding="utf-8") as f:
            linhas = [json.loads(l) for l in f.readlines()][-1000:]
        # Filtros
        col1, col2 = st.columns(2)
        perfil = col1.selectbox("Filtrar por perfil", ["Todos"] + ["3eye","Multiplicação Divina","Quant","Conservador","Agressivo","IA Total"])
        data_ini = col2.date_input("A partir de:", value=datetime.now())
        logs_filtrados = []
        for reg in reversed(linhas):
            if perfil != "Todos" and f'perfil {perfil.lower()}' not in str(reg['evento']).lower():
                continue
            if "timestamp" in reg and reg["timestamp"][:10] < data_ini.strftime("%Y-%m-%d"):
                continue
            logs_filtrados.append(reg)
        for reg in logs_filtrados[:100]:
            st.markdown(f"**{reg['timestamp']}**: {reg['evento']}")
        if st.button("Exportar log auditoria"):
            st.download_button(
                label="Baixar arquivo de log",
                data=json.dumps(logs_filtrados, indent=2, ensure_ascii=False),
                file_name="log_auditoria_filtrado.json"
            )
    except Exception as e:
        st.error(f"Erro ao carregar logs: {e}")
