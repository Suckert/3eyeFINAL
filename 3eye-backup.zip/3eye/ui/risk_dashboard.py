import streamlit as st
import pandas as pd
import numpy as np
from ui.side_menu import super_sidebar
super_sidebar()

def risk_dashboard(df):
    st.title("Painel de Risco 3EYE SUPREMO")
    st.info("Aqui você acompanha drawdown, volatilidade, VaR e exposição da carteira.")
    if df is not None and len(df) > 0:
        returns = df['close'].pct_change().dropna()
        drawdown = (df['close'] / df['close'].cummax() - 1).min()
        var_95 = np.percentile(returns, 5)
        st.metric("Drawdown Máximo", f"{drawdown:.2%}")
        st.metric("VaR (5%)", f"{var_95:.2%}")
        st.line_chart(returns, use_container_width=True)
    else:
        st.warning("Carregue um DataFrame com preços para ver o painel de risco.")
