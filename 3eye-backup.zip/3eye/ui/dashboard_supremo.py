import streamlit as st
import pandas as pd
import numpy as np
from utils import listar_plugins, executar_plugin
from core.logger_auditoria import get_audit_log, log_event
from core.binance_exec_supremo import BinanceExecutor
import datetime
from ui.charts import show_heatmap
from modules.risk_engine import calcular_risco, calcular_var
from ui.side_menu import super_sidebar
super_sidebar()

def receber_sinais_externos():
    # Leitura simulada/real de sinais externos
    try:
        with open("sinais_externos.txt") as f:
            sinais = [linha.strip() for linha in f.readlines()[-10:]]
        return sinais
    except:
        return ["Nenhum sinal externo recebido."]

def painel_supremo():
    st.title("🦾 Painel SUPREMO — Execução e Monitoramento Máximo")
    st.markdown("#### Sistema 3EYE SUPREMO — Visão Total de Estratégias, Carteira, Sinais e Risco")

    # Status IA e Autoexec
    status_ia = st.session_state.get("ia_status", "🟢 ONLINE")
    modo = "AutoExec" if st.session_state.get("ia_auto", True) else "Manual"
    saldo_atual = st.session_state.get("saldo", 10000)
    lucro_total = st.session_state.get("lucro_acumulado", 1200)
    drawdown = st.session_state.get("drawdown", -3.5)
    sharpe = st.session_state.get("sharpe", 1.18)

    st.markdown("---")
    st.markdown(f"""
    <div style="display: flex; gap: 18px;">
      <div style="background: #202A44; color: #fff; border-radius:18px; padding:24px 32px;">
        <h2 style="color:#3cf672;">Saldo Atual</h2>
        <h1 style="font-size:2.6em;">R$ {saldo_atual:,.2f}</h1>
      </div>
      <div style="background: #212C26; color: #fff; border-radius:18px; padding:24px 32px;">
        <h2 style="color:#ffdb3d;">Lucro Acumulado</h2>
        <h1 style="font-size:2.3em;">R$ {lucro_total:,.2f}</h1>
        <span>({lucro_total/saldo_atual:.2%})</span>
      </div>
      <div style="background: #32202A; color: #fff; border-radius:18px; padding:24px 32px;">
        <h2>Drawdown</h2>
        <h1 style="font-size:2.1em;">{drawdown:.2f}%</h1>
      </div>
      <div style="background: #191f3a; color: #fff; border-radius:18px; padding:24px 32px;">
        <h2>Sharpe</h2>
        <h1 style="font-size:2.1em;">{sharpe:.2f}</h1>
      </div>
      <div style="background: #0e131d; color: #52ff7c; border-radius:18px; padding:24px 32px;">
        <h2>Status IA</h2>
        <h1 style="font-size:2.1em;">{status_ia}</h1>
      </div>
      <div style="background: #262a1f; color: #ffe760; border-radius:18px; padding:24px 32px;">
        <h2>Modo</h2>
        <h1 style="font-size:2.1em;">{modo}</h1>
      </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    st.header("🔌 Execução Avançada de Estratégias e Plug-ins")
    plugins = listar_plugins()
    escolha = st.selectbox("Escolha um Plug-in/Estratégia para Monitorar ou Executar", plugins)
    col_exec, col_hist, col_all = st.columns([1,2,1])

    # Execução individual
    if col_exec.button(f"Executar '{escolha}'"):
        binance = BinanceExecutor()
        resultado = executar_plugin(escolha, binance_executor=binance)
        st.success(f"Resultado da execução de {escolha}: {resultado}")
        log_event({"painel": "supremo", "plugin": escolha, "resultado": str(resultado)[:120]}, nivel="EXEC")

    # Execução de todos plug-ins em lote
    if col_all.button("Executar TODOS plug-ins agora! 🚀"):
        binance = BinanceExecutor()
        all_results = {}
        for plug in plugins:
            try:
                res = executar_plugin(plug, binance_executor=binance)
                all_results[plug] = res
            except Exception as e:
                all_results[plug] = f"Erro: {e}"
        st.info(f"Resultado geral: {all_results}")
        log_event({"painel": "supremo", "todos_plugins": str(all_results)[:200]}, nivel="AUTOEXEC")

    # Histórico de execuções, busca e filtro
    df_log = get_audit_log()
    if not df_log.empty:
        plugin_logs = df_log[df_log["acao"].str.contains(escolha)]
        filtro = col_hist.text_input("Filtrar logs:", "")
        if filtro:
            plugin_logs = plugin_logs[plugin_logs["acao"].str.contains(filtro)]
        if not plugin_logs.empty:
            col_hist.markdown("#### Logs deste Plug-in:")
            col_hist.dataframe(plugin_logs.tail(20)[["timestamp","acao","perfil"] + [col for col in plugin_logs.columns if col not in ["timestamp","acao","perfil"]][:3]], use_container_width=True)
        else:
            col_hist.info("Sem logs recentes deste plug-in/estratégia.")
    else:
        st.info("Nenhum log de execução disponível.")

    st.markdown("---")
    st.header("📈 Dashboards de Desempenho & Heatmap Estratégias")
    # Exemplo de resultados simulados
    ativos = ["BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT"]
    lucros = np.random.uniform(1, 10, size=4)
    riscos = np.random.uniform(0.05, 0.15, size=4)
    show_heatmap(lucros, riscos, ativos)
    st.line_chart(pd.DataFrame({"Lucro Acumulado": np.cumsum(np.random.randn(60)*10+60)}))
    st.caption("Heatmap: Lucro x Risco das Estratégias Ativas")

    st.markdown("---")
    st.header("🌐 Sinais Externos (Telegram, Webhook, Discord, TradingView, etc.)")
    sinais = receber_sinais_externos()
    for s in sinais:
        st.info(s)

    st.markdown("---")
    st.header("📝 Logs Recentes do Sistema (Busca e Filtragem)")
    if not df_log.empty:
        filtro_log = st.text_input("Filtrar logs gerais:", "")
        logs_filtrados = df_log
        if filtro_log:
            logs_filtrados = logs_filtrados[logs_filtrados["acao"].str.contains(filtro_log, case=False)]
        st.dataframe(logs_filtrados.tail(25), use_container_width=True)

    st.markdown("---")
    st.header("⚙️ Execução Manual Avançada")
    colb1, colb2, colb3 = st.columns(3)
    ativo = colb1.text_input("Ativo", value="BTC/USDT")
    side = colb2.selectbox("Side", ["buy", "sell"])
    amount = colb3.number_input("Quantidade", min_value=0.001, value=0.01)
    tipo_ordem = colb1.selectbox("Tipo de Ordem", ["market", "limit"])
    preco = colb2.number_input("Preço (para limit)", min_value=0.0, value=0.0)
    if colb3.button("Executar Trade Manual"):
        binance = BinanceExecutor()
        if tipo_ordem == "market":
            resp = binance.executar_ordem(ativo, side, amount)
        else:
            resp = binance.spot.create_limit_buy_order(ativo, amount, preco) if side == "buy" else binance.spot.create_limit_sell_order(ativo, amount, preco)
        st.success(f"Ordem executada: {resp}")
        log_event({"painel": "supremo", "ordem_manual": f"{side} {amount} {ativo} {tipo_ordem}"}, nivel="MANUAL")

    st.markdown("---")
    st.header("🚦 Monitor de Alertas, Risco e VaR")
    # Simulação de cálculo de risco
    risco_atual = calcular_risco(np.random.normal(0, 0.1, 100))
    var_atual = calcular_var(np.random.normal(0, 0.1, 100))
    if risco_atual > 0.2:
        st.error(f"🚨 ALERTA: Risco elevado detectado! (Risk={risco_atual:.2f})")
    else:
        st.success(f"Risco atual sob controle (Risk={risco_atual:.2f})")
    st.info(f"VaR (Value at Risk) estimado: {var_atual:.2%}")

    st.caption("""
    Painel SUPREMO: visualização institucional em tempo real, execução plugável, heatmap de risco, sinais externos, automação, logs e ação manual — 3EYE SUPREMO.  
    Dica: Explore todos os menus laterais para exportar, rebalancear, customizar e operar com IA máxima.
    """)

# Para rodar: basta importar painel_supremo() no seu app.py e chamar no menu.
