import streamlit as st
from ui.side_menu import side_menu
from ui.charts import kpi_cards, multi_coin_chart, heatmap_score, capital_chart, timeline, custom_css
from core.logger_auditoria import get_audit_log
from utils import listar_plugins, executar_plugin

def main_painel(**managers):
    custom_css()
    menu = side_menu(
        ["Dashboard", "Carteira", "3eye Vision", "Operações", "Rebalance", "Macros/Plug-ins", "Logs", "Notícias", "Configuração"],
        "Dashboard", logo_path="3eye-logo-v2.png"
    )

    if menu == "Dashboard":
        st.title("🟢 3EYE Apple Vision — Dashboard")
        kpi_cards([
            {"label": "Capital Atual", "valor": "R$ 15.800", "delta": "+7%"},
            {"label": "Lucro Dia", "valor": "R$ 1.230", "delta": "+2%"},
            {"label": "Sharpe", "valor": "1.18"},
            {"label": "Drawdown", "valor": "-3.9%"}
        ])
        if hasattr(managers["carteira"], "carteira") and not managers["carteira"].carteira.empty:
            capital_chart(managers["carteira"].carteira)
        if "timeline" in managers and managers["timeline"]:
            timeline(managers["timeline"])

    if menu == "Carteira":
        st.title("Carteira Completa")
        st.dataframe(managers["carteira"].carteira, use_container_width=True)

    if menu == "3eye Vision":
        st.title("3eye Vision — Multiativos")
        multi_coin_chart(managers.get("dados_candles", {}), managers.get("dados_indicadores", {}))
        st.subheader("Heatmap de Oportunidades")
        heatmap_score(managers.get("score", {"BTC": 0.8, "ETH": 0.3, "BNB": -0.2}))

    if menu == "Operações":
        st.title("Operações Executadas")
        st.dataframe(managers["carteira"].historico if hasattr(managers["carteira"], "historico") else [], use_container_width=True)

    if menu == "Rebalance":
        st.title("Rebalanceamento Inteligente")
        if st.button("Executar Rebalanceamento"):
            mercado = managers.get("mercado", {})
            plugins = listar_plugins()
            if plugins:
                ordens = executar_plugin(plugins[0], carteira=managers["carteira"], mercado=mercado)
                st.success("Rebalanceamento via plug-in realizado.")
                st.json(ordens)
        st.write("Histórico:")
        st.json(managers["rebalance"].historico[-1] if managers["rebalance"].historico else {})

    if menu == "Macros/Plug-ins":
        st.title("Macros, Plug-ins e Estratégias Avançadas")
        plugins = listar_plugins()
        escolha = st.selectbox("Escolha um Plug-in de Estratégia", plugins)
        if st.button("Executar Plug-in"):
            resultado = executar_plugin(escolha, carteira=managers["carteira"], mercado=managers.get("mercado", {}))
            st.json(resultado)

    if menu == "Logs":
        st.title("Logs & Auditoria")
        st.dataframe(get_audit_log(), use_container_width=True)

    if menu == "Notícias":
        st.title("Notícias & Sentimento")
        st.info("Últimas notícias, FUD/FOMO alerts, eventos macro, sentimento do mercado.")

    if menu == "Configuração":
        st.title("Configuração do Painel")
        st.json(managers["config"].config)
