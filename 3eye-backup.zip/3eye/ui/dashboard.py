import streamlit as st
from core.portfolio_manager import CarteiraDinamicaIA
from modules.news_trading import OlhoDeSalomao
from modules.stop_manager import StopManager
from modules.score_engine import ScoreEngine
from modules.walk_forward import walk_forward_analysis
from ui.charts import show_heatmap, plot_walk_forward
from ui.side_menu import super_sidebar
super_sidebar()


def main_dashboard():
    st.title("🦾 Painel SUPREMO 3EYE — Fase 2 Total")
    ativos = st.multiselect("Ativos:", ["BTC/USDT","ETH/USDT","BNB/USDT","SOL/USDT"], default=["BTC/USDT","ETH/USDT"])
    estrategias = st.multiselect("Estratégias:", ["supremo_ia","hedge","copytrade"], default=["supremo_ia"])
    salomao = OlhoDeSalomao(news_api_key=st.secrets["NEWSAPI"])
    news = salomao.get_news()
    st.markdown("### Últimas Notícias")
    for n in news:
        st.caption(f"{n['date']} — {n['title']}")
    score_news = salomao.score_noticia_ativos(ativos)
    score_engine = ScoreEngine()
    retornos, volumes, sentimentos, plugin_hist = {}, {}, {}, {}
    for ativo in ativos:
        retornos[ativo], volumes[ativo], sentimentos[ativo], plugin_hist[ativo] = 0.05, 0.1, 0.0, 0.1
    score = score_engine.calcular_score(retornos, volumes, sentimentos, plugin_hist, noticia=score_news)
    st.write("Score de cada ativo:", score)
    executor = CarteiraDinamicaIA(binance_executor=None)
    alocacoes = executor.alocar_dinamico({(a, estrategias[0]): score[a] for a in ativos})
    if st.button("Executar Alocação IA"):
        res = executor.executar_alocacao(alocacoes)
        st.write("Resultado execução:", res)
    stop_manager = StopManager()
    candles = [[i,1,1,1,1+0.01*i,1] for i in range(25)]
    st.write("Stop:", stop_manager.calcular_stop(candles))
    st.write("Alvo:", stop_manager.calcular_alvo(candles))
    st.write("Trailing:", stop_manager.ajustar_trailing(candles))
    lucros = [score[a] for a in ativos]
    riscos = [abs(score[a]-0.1) for a in ativos]
    st.markdown("#### Heatmap Lucro x Risco")
    show_heatmap(lucros, riscos, ativos)
    # Walk-forward Analysis Exemplo
    st.markdown("#### Walk-Forward Analysis")
    # data = seu dataframe de preços/retornos
    # plug_in_func = seu plug-in treinável
    # df_result, mse = walk_forward_analysis(data, plug_in_func)
    # plot_walk_forward(df_result)
