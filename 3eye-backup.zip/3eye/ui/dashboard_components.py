import streamlit as st
import pandas as pd
import plotly.graph_objs as go

def kpi_cards():
    # Exemplos de KPIs (substitua por dados reais)
    st.columns([1,1,1,1])
    st.metric("Capital Inicial", "R$ 10.000,00")
    st.metric("Capital Atual", "R$ 15.600,00", delta="56%")
    st.metric("Maior Drawdown", "-4,2%")
    st.metric("Sharpe", "1.18")

    from core.backup_scheduler import backup_manual_via_painel,                      restaurar_backup_via_painel
         backup_manual_via_painel()
restaurar_backup_via_painel()


def capital_chart():
    df = pd.read_csv("evolucao_capital.csv")  # Use seu DataFrame real!
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df['data'], y=df['capital_ia'], mode='lines+markers', name='IA'))
    fig.add_trace(go.Scatter(x=df['data'], y=df['capital_trader'], mode='lines', name='Trader'))
    st.plotly_chart(fig, use_container_width=True)

def multi_coin_chart():
    # Simule/importe candles múltiplas moedas
    df = pd.read_csv("BTCUSDT.csv")
    fig = go.Figure(data=[
        go.Candlestick(
            x=df['date'], open=df['open'], high=df['high'],
            low=df['low'], close=df['close'], name="BTC"
        )
    ])
    # Adicione RSI/MACD overlay
    fig.add_trace(go.Scatter(x=df['date'], y=df['rsi'], mode='lines', name='RSI', yaxis='y2'))
    st.plotly_chart(fig, use_container_width=True)

def score_heatmap():
    # Exemplo simples de heatmap de scores
    import seaborn as sns
    import matplotlib.pyplot as plt
    scores = pd.DataFrame({"Ativo": ["BTC", "ETH", "BNB"], "Score": [0.8, 0.3, -0.2]})
    plt.figure(figsize=(4,2))
    sns.heatmap(scores.set_index("Ativo"), annot=True, cmap="RdYlGn", cbar=False)
    st.pyplot(plt)

def logs_table(logs):
    st.dataframe(logs)

def alerts_panel():
    # Exibe últimos alertas, exemplo simples
    st.warning("IA fallback ativado às 09:45 - Operando no modo backup!")
    st.info("Novo sinal disponível para BTC/USDT!")
