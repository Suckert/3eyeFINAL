import streamlit as st
from core.config_manager import carregar_config, salvar_config

def painel_config_advanced():
    st.title("Configuração Avançada SUPREMO")
    config = carregar_config()
    api_binance = st.text_input("API Key Binance", value=config.get("API_KEY_BINANCE", ""))
    secret_binance = st.text_input("Secret Key Binance", value=config.get("SECRET_KEY_BINANCE", ""), type="password")
    news_api = st.text_input("NewsAPI Key", value=config.get("NEWSAPI", ""))
    perfil_padrao = st.selectbox("Perfil Padrão", ["3eye", "Multiplicação Divina", "Gestor Quant", "Conservador", "Agressivo", "IA Total"],
                                 index=["3eye", "Multiplicação Divina", "Gestor Quant", "Conservador", "Agressivo", "IA Total"].index(config.get("PERFIL_PADRAO", "3eye")))
    auto_backup = st.checkbox("Backup Automático (30min)", value=config.get("BACKUP_AUTO", True))
    if st.button("Salvar Config"):
        config["API_KEY_BINANCE"] = api_binance
        config["SECRET_KEY_BINANCE"] = secret_binance
        config["NEWSAPI"] = news_api
        config["PERFIL_PADRAO"] = perfil_padrao
        config["BACKUP_AUTO"] = auto_backup
        salvar_config(config)
        st.success("Configuração salva com sucesso.")
    if st.button("Forçar Reload"):
        st.experimental_rerun()
    st.info("Configuração persistente. As alterações entram em vigor ao reiniciar ou recarregar painel.")
