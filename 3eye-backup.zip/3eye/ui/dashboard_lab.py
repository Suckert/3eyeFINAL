import streamlit as st
import os
import importlib
from pathlib import Path
from ui.side_menu import super_sidebar
super_sidebar()

st.set_page_config(page_title="Supreme LAB - Validação & Teste", layout="wide")
st.title("🧪 Supreme LAB — Diagnóstico, Integração e Testes 3EYE SUPREMO")

# 1. Diagnóstico de Integração Completa
st.header("✅ Validação de Módulos/Painéis e Plug-ins")
modulos = [
    "ui.dashboard_apple", "ui.dashboard_quantum", "ui.dashboard_dazarabia", "ui.dashboard_lab",
    "ui.painel_auditoria", "ui.config_advanced", "ui.risk_dashboard", "ui.onboarding",
    "plugins.supremo_ia", "plugins.copytrade", "plugins.scalping", "plugins.arbitrage", "plugins.hedge",
    "core.logger_auditoria", "core.binance_exec_supremo", "core.backup_scheduler", "modules.utils"
]
res_modulos = []
for m in modulos:
    try:
        importlib.import_module(m)
        res_modulos.append(f"🟢 {m}")
    except Exception as e:
        res_modulos.append(f"🔴 {m} — {e}")
st.code("\n".join(res_modulos), language="python")

# 2. Validação de Variáveis de Ambiente
st.header("🔑 Variáveis de Ambiente (.env)")
required_env = ["API_KEY_BINANCE", "SECRET_KEY_BINANCE", "NEWSAPI_KEY"]
res_env = []
for var in required_env:
    if os.getenv(var):
        res_env.append(f"🟢 {var}: OK")
    else:
        res_env.append(f"🔴 {var}: NÃO ENCONTRADA")
st.code("\n".join(res_env), language="bash")

# 3. Validação de Pastas
st.header("📁 Pastas de Dados, Logs, Exportação")
pastas = ["data/logs", "data/backups", "export"]
res_pastas = []
for p in pastas:
    Path(p).mkdir(parents=True, exist_ok=True)
    if os.path.exists(p):
        res_pastas.append(f"🟢 {p}: OK")
    else:
        res_pastas.append(f"🔴 {p}: NÃO ENCONTRADA")
st.code("\n".join(res_pastas), language="bash")

# 4. Configurações Globais
st.header("⚙️ Configurações Gerais do Sistema")
col1, col2, col3 = st.columns(3)
perfil = col1.selectbox("Perfil", ["Conservador", "Moderado", "Agressivo", "IA Inteligente", "SUPREMO IA-Alavancada"])
tema = col2.selectbox("Tema Visual", ["Supremo", "Apple", "Quantum", "Dazarabia"])
modo = col3.selectbox("Modo", ["Simulado", "Real", "Testes"])
if st.button("💾 Salvar Configuração"):
    st.success("Configuração salva!")

# 5. Testes de Execução dos Plugins
st.header("🔌 Teste de Plug-ins/Execução Real")
with st.expander("Executar Diagnóstico dos Plugins/Executor Binance"):
    try:
        from plugins.supremo_ia import executar as exec_supremo_ia
        st.write("Plug-in Supremo IA: OK")
    except Exception as e:
        st.error(f"Erro Supremo IA: {e}")
    try:
        from core.binance_exec_supremo import BinanceExecutor
        be = BinanceExecutor()
        st.write("BinanceExecutor: OK")
    except Exception as e:
        st.error(f"Erro BinanceExecutor: {e}")

# 6. Backup/Restore manual
st.header("🗃️ Backup & Restore")
colb1, colb2 = st.columns(2)
if colb1.button("Backup Manual Agora"):
    from core.backup_scheduler import criar_backup
    paths = criar_backup()
    st.success(f"Backup criado: {paths}")
if colb2.button("Restaurar Último Backup"):
    st.info("Restore: (simulado) — Em breve versão real!")

# 7. Logs Recentes
st.header("📑 Logs Recentes")
try:
    with open("data/logs/log_auditoria.txt", encoding="utf-8") as f:
        logs = f.readlines()[-15:]
        st.code("".join(logs))
except:
    st.warning("Sem logs para mostrar.")

# 8. Diagnóstico Final
if all("🟢" in x for x in (res_modulos+res_env+res_pastas)):
    st.success("TUDO OK: Sistema totalmente integrado e validado!")
else:
    st.error("Atenção: Há módulos, variáveis ou pastas faltando — revise antes de usar produção!")

st.caption("Supreme LAB: Central de Diagnóstico, Teste e Expansão do 3EYE SUPREMO.")
