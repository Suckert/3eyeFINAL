import streamlit as st

def exibir_onboarding():
    st.title("Bem-vindo ao 3EYE SUPREMO!")
    st.markdown("""
    Parabéns por acessar o sistema mais avançado do mercado.
    
    **Passo 1:** Configure sua API Binance, NewsAPI e variáveis no painel avançado.<br>
    **Passo 2:** Escolha seu perfil operacional.  
    - *3eye*: Inteligência adaptativa (padrão)
    - *Multiplicação Divina*: Foco em expansão de capital, hedge e diversificação máxima
    - *Gestor Quant*: Quantitativo, otimização de Sharpe
    - *Agressivo*: Lucro máximo, maior risco
    - *IA Total*: Tudo automático, 24h
    - *Conservador*: Preservação de capital, hedge contínuo

    **Passo 3:** Teste estratégias e plugins no Supreme Lab.<br>
    **Passo 4:** Rode backtests com Walk-Forward Analysis no painel SUPREMO.<br>
    **Passo 5:** Exporte, faça backup e monitore tudo no Painel Auditoria.

    ---
    **Links úteis:**
    - [Manual Completo](./README_MANUAL.md)
    - [Tutorial Vídeo](https://youtu.be/xxxxxx)
    - [Contato Suporte](mailto:support@3eye.com)
    """, unsafe_allow_html=True)
    if st.button("Ir para Painel Supremo"):
        st.session_state["tema"] = "Painel SUPREMO"
        st.experimental_rerun()
