# vision.py - arquivo de sistema 3eye
