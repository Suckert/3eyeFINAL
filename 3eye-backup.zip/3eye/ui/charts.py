import streamlit as st
import pandas as pd
import plotly.graph_objs as go
import matplotlib.pyplot as plt
import seaborn as sns

def plot_walk_forward(df=None):
    import streamlit as st
    st.info("Plot Walk Forward (placeholder)")

def kpi_cards(kpis):
    kpi_cols = st.columns(len(kpis))
    for col, kpi in zip(kpi_cols, kpis):
        col.metric(kpi["label"], kpi["valor"], kpi.get("delta",""))

def multi_coin_chart(dados_candles, dados_indicadores=None):
    fig = go.Figure()
    for moeda, df in dados_candles.items():
        fig.add_trace(go.Candlestick(
            x=df['date'], open=df['open'], high=df['high'], low=df['low'], close=df['close'], name=moeda
        ))
        if dados_indicadores and moeda in dados_indicadores:
            fig.add_trace(go.Scatter(
                x=df['date'], y=dados_indicadores[moeda]['RSI'], mode='lines', name=f"{moeda} RSI", yaxis='y2'
            ))
    fig.update_layout(xaxis_rangeslider_visible=False)
    st.plotly_chart(fig, use_container_width=True)

def heatmap_score(scores):
    df = pd.DataFrame(list(scores.items()),columns=["Ativo","Score"])
    plt.figure(figsize=(4,2))
    sns.heatmap(df.set_index("Ativo"), annot=True, cmap="RdYlGn", cbar=False)
    st.pyplot(plt)

def capital_chart(df_capital):
    fig = go.Figure()
    for col in df_capital.columns:
        if col != 'data':
            fig.add_trace(go.Scatter(x=df_capital['data'], y=df_capital[col], mode='lines+markers', name=col))
    st.plotly_chart(fig, use_container_width=True)

def timeline(df):
    import plotly.express as px
    fig = px.timeline(df, x_start="DataInicio", x_end="DataFim", y="Evento", color="Tipo")
    st.plotly_chart(fig)

def custom_css():
    st.markdown("""
    <style>
    /* KPI e cards */
    .stMetric {font-size:1.3em; font-weight:bold;}
    /* Sidebar custom */
    .css-1d391kg {background:#191e24;}
    /* Neon highlight */
    .main-title {color:#36f5e0;}
    /* Gold highlight */
    .lux-title {color:#eac042;}
    /* ... outras customizações ... */
    </style>
    """, unsafe_allow_html=True)
