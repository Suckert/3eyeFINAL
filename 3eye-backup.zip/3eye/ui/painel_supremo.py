import streamlit as st
import pandas as pd
import datetime
from utils import listar_plugins, executar_plugin
from core.logger_auditoria import get_audit_log
from core.binance_exec_supremo import BinanceExecutor
from ui.side_menu import super_sidebar
super_sidebar()

def main_dashboard(perfil="SUPREMO IA-Alavancada"):
    st.title("🦾 Painel SUPREMO — Estratégias em Tempo Real")
    col1, col2, col3 = st.columns([2,2,1])

    saldo_atual = st.session_state.get("saldo", 10000)
    lucro_total = st.session_state.get("lucro_acumulado", 1200)
    drawdown = st.session_state.get("drawdown", -3.5)
    sharpe = st.session_state.get("sharpe", 1.18)
    modo = "Auto" if st.session_state.get("ia_auto", True) else "Manual"
    col1.metric("Saldo Atual", f"R$ {saldo_atual:,.2f}")
    col2.metric("Lucro Acumulado", f"R$ {lucro_total:,.2f}", delta=f"{lucro_total/saldo_atual:.2%}")
    col3.metric("Drawdown", f"{drawdown}%", delta_color="inverse")
    st.caption(f"Sharpe: {sharpe} | Modo: {modo}")

    st.markdown("---")
    st.header("🔌 Estratégias e Plug-ins Ativos")
    plugins = listar_plugins()
    escolha = st.selectbox("Selecione a Estratégia/Plug-in para Monitorar e Executar", plugins)
    col_exec, col_hist = st.columns([1,2])

    if col_exec.button(f"Executar '{escolha}' AGORA"):
        binance = BinanceExecutor()
        resultado = executar_plugin(escolha, binance_executor=binance)
        st.success(f"Resultado da execução: {resultado}")

    df_log = get_audit_log()
    if not df_log.empty:
        plugin_logs = df_log[df_log["acao"].str.contains(escolha)]
        if not plugin_logs.empty:
            col_hist.markdown("#### Logs dessa Estratégia:")
            col_hist.dataframe(plugin_logs.tail(15)[["timestamp","acao","perfil"] + [col for col in plugin_logs.columns if col not in ["timestamp","acao","perfil"]][:2]], use_container_width=True)
        else:
            col_hist.info("Sem logs recentes deste plug-in.")

    st.markdown("---")
    st.header("📈 Estratégias Ativas em Tempo Real")
    binance = BinanceExecutor()
    results = []
    for plug in plugins:
        try:
            out = executar_plugin(plug, binance_executor=binance)
            status = "OK" if isinstance(out, (dict, list)) else str(out)[:120]
        except Exception as e:
            status = f"ERRO: {e}"
        results.append({"Plug-in": plug, "Status/Resultado": status, "Timestamp": datetime.datetime.now().isoformat()})
    df = pd.DataFrame(results)
    st.dataframe(df, use_container_width=True)

    st.markdown("---")
    st.header("🌐 Sinais Externos (Telegram, Webhook, Discord, etc.)")
    sinais = []
    try:
        with open("sinais_externos.txt") as f:
            sinais = [linha.strip() for linha in f.readlines()[-5:]]
    except:
        sinais = ["Nenhum sinal externo recebido."]
    for s in sinais:
        st.info(s)

    st.markdown("---")
    st.header("📝 Logs Recentes do Sistema")
    if not df_log.empty:
        st.dataframe(df_log.tail(20), use_container_width=True)

    st.markdown("---")
    st.header("⚙️ Execução Manual")
    colb1, colb2 = st.columns(2)
    ativo = colb1.text_input("Ativo", value="BTC/USDT")
    side = colb2.selectbox("Side", ["buy", "sell"])
    amount = colb1.number_input("Quantidade", min_value=0.001, value=0.01)
    if colb2.button("Executar Trade Manual"):
        binance = BinanceExecutor()
        resp = binance.executar_ordem(ativo, side, amount)
        st.success(f"Ordem executada: {resp}")

    st.markdown("---")
    st.header("🚦 Monitor de Alertas e Risco")
    alerta = st.session_state.get("alerta", "OK")
    if alerta != "OK":
        st.error(f"🚨 ALERTA: {alerta}")
    else:
        st.success("Nenhum alerta crítico no momento.")
    st.caption("Painel SUPREMO: visualização em tempo real, execução de estratégias plugáveis, sinais externos, monitoramento, logs e ação manual — 3EYE SUPREMO.")
