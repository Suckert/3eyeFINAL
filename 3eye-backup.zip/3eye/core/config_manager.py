import json, os
from core.logger_auditoria import log_event

class ConfigManager:

    def carregar_config():
"""Carrega configuração do sistema."""
    	if os.path.exists("config.json"):
        with open("config.json") as f:
            return json.load(f)
    return {}

    def salvar_config(config):
"""Salva configuração do sistema."""
        with open("config.json", "w") as f:
        json.dump(config, f, indent=2)
    

    def __init__(self, arquivo="config.json"):
        self.arquivo = arquivo
        self.config = {}
        self.carregar()
    def carregar(self):
        if os.path.exists(self.arquivo):
            with open(self.arquivo) as f:
                self.config = json.load(f)
        else:
            self.config = {}
    def salvar(self):
        with open(self.arquivo,"w") as f:
            json.dump(self.config, f, indent=2)
        log_event({"acao":"salvar_config","arquivo":self.arquivo,"config":self.config})
    def get(self, chave, padrao=None):
        return self.config.get(chave,padrao)
    def set(self, chave, valor):
        self.config[chave]=valor
        self.salvar()
    def exportar(self, caminho):
        with open(caminho, "w") as f:
            json.dump(self.config, f, indent=2)
        log_event({"acao":"exportar_config","caminho":caminho})
    def importar(self, caminho):
        with open(caminho) as f:
            self.config = json.load(f)
        self.salvar()
        log_event({"acao":"importar_config","caminho":caminho})
