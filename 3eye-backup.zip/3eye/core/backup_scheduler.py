import os
import shutil
import threading
import time
from datetime import datetime, timedelta
from core.logger_auditoria import log_event

BACKUP_DIR = "data/backups"
FILES_TO_BACKUP = [
    "data/logs/log_auditoria.txt",
    "sinais_externos.txt",
    "plugins/hist_supremo_ia.csv",
    "data/configs/supremo_config.json"
]
BACKUP_INTERVAL_MINUTES = 30     # intervalo entre backups automáticos
MAX_BACKUPS = 48                 # máximo de arquivos de backup mantidos (exemplo: 24h com backup a cada 30min)

def criar_backup(backup_type="auto"):
    """
    Realiza backup de todos os arquivos configurados.
    Salva com timestamp e tipo (auto/manual/incremental).
    """
    os.makedirs(BACKUP_DIR, exist_ok=True)
    backup_time = datetime.now().strftime("%Y%m%d_%H%M%S")
    arquivos_salvos = []
    for f in FILES_TO_BACKUP:
        if os.path.exists(f):
            dest = os.path.join(BACKUP_DIR, f"{os.path.basename(f)}_{backup_type}_{backup_time}")
            shutil.copy(f, dest)
            arquivos_salvos.append(dest)
    log_event(f"Backup {backup_type.upper()} executado. Arquivos: {arquivos_salvos}", nivel="BACKUP")
    limpar_backups_antigos()
    return arquivos_salvos

def criar_backup_incremental():
    """
    Faz backup só dos arquivos que mudaram desde o último backup.
    """
    latest_times = get_ultimo_backup_timestamps()
    novos = []
    for f in FILES_TO_BACKUP:
        if os.path.exists(f):
            mtime = os.path.getmtime(f)
            if f not in latest_times or mtime > latest_times[f]:
                novos.append(f)
    if novos:
        return criar_backup(backup_type="incremental")
    else:
        log_event("Backup incremental: Nenhuma alteração detectada.", nivel="BACKUP")
        return []

def get_ultimo_backup_timestamps():
    """
    Pega o timestamp do último backup para cada arquivo.
    """
    arquivos = [f for f in os.listdir(BACKUP_DIR) if os.path.isfile(os.path.join(BACKUP_DIR, f))]
    last_time = {}
    for arquivo in arquivos:
        for base in FILES_TO_BACKUP:
            if os.path.basename(base) in arquivo:
                file_path = os.path.join(BACKUP_DIR, arquivo)
                last_time[base] = os.path.getmtime(file_path)
    return last_time

def restaurar_backup(backup_file_name):
    """
    Restaura um arquivo de backup específico para seu local original.
    """
    src = os.path.join(BACKUP_DIR, backup_file_name)
    for base in FILES_TO_BACKUP:
        if os.path.basename(base) in backup_file_name:
            shutil.copy(src, base)
            log_event(f"Backup restaurado: {src} -> {base}", nivel="BACKUP")
            return True
    log_event(f"Falha ao restaurar backup (arquivo não encontrado): {backup_file_name}", nivel="ERROR")
    return False

def listar_backups():
    """
    Lista todos os arquivos de backup disponíveis.
    """
    return sorted([f for f in os.listdir(BACKUP_DIR) if os.path.isfile(os.path.join(BACKUP_DIR, f))], reverse=True)

def limpar_backups_antigos(max_backups=MAX_BACKUPS):
    """
    Remove backups antigos acima do limite configurado.
    """
    arquivos = listar_backups()
    if len(arquivos) > max_backups:
        for f in arquivos[max_backups:]:
            try:
                os.remove(os.path.join(BACKUP_DIR, f))
                log_event(f"Backup antigo removido: {f}", nivel="BACKUP")
            except Exception as e:
                log_event(f"Erro ao remover backup {f}: {e}", nivel="ERROR")

def agendar_backup_automatico(intervalo=BACKUP_INTERVAL_MINUTES):
    """
    Agenda backups automáticos em background (thread).
    """
    def loop_backup():
        while True:
            criar_backup("auto")
            time.sleep(intervalo * 60)
    thread = threading.Thread(target=loop_backup, daemon=True)
    thread.start()
    log_event(f"Backup automático agendado para cada {intervalo} minutos.", nivel="BACKUP")
    return thread

def backup_manual_via_painel():
    """
    Use em seu painel Streamlit: botão de backup manual.
    """
    from streamlit import session_state
    if 'backup_executado' not in session_state:
        session_state['backup_executado'] = False
    if st.button("Executar Backup Manual AGORA"):
        criar_backup("manual")
        session_state['backup_executado'] = True
        st.success("Backup manual executado com sucesso.")

def restaurar_backup_via_painel():
    """
    Botão para restaurar backup no painel Streamlit.
    """
    arquivos = listar_backups()
    escolha = st.selectbox("Escolha backup para restaurar:", arquivos)
    if st.button("Restaurar Backup Selecionado"):
        ok = restaurar_backup(escolha)
        if ok:
            st.success("Backup restaurado com sucesso.")
        else:
            st.error("Falha ao restaurar backup.")

# Ao iniciar app.py (modo produção), pode rodar:
# from core.backup_scheduler import agendar_backup_automatico
# agendar_backup_automatico()

