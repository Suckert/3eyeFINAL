import ccxt
import os
from core.logger_auditoria import log_event

class BinanceExecutor:
    """
    Executor geral para Spot, Futures e Opções via Binance (CCXT)
    Inclui execução real e mock, logging e integração para estratégias Supreme.
    """

    def __init__(self):
        self.api_key = os.getenv("API_KEY_BINANCE") or os.getenv("BINANCE_API_KEY")
        self.api_secret = os.getenv("SECRET_KEY_BINANCE") or os.getenv("BINANCE_SECRET_KEY")
        # Checa se as chaves estão corretas
        if not self.api_key or not self.api_secret:
            raise ValueError("API_KEY_BINANCE e SECRET_KEY_BINANCE não encontrados no .env")
        self.spot = ccxt.binance({
            'apiKey': self.api_key,
            'secret': self.api_secret,
            'enableRateLimit': True,
            'options': {'defaultType': 'spot'}
        })
        self.futures = ccxt.binance({
            'apiKey': self.api_key,
            'secret': self.api_secret,
            'enableRateLimit': True,
            'options': {'defaultType': 'future'}
        })
        # CCXT só tem opção para "option" se ativar, caso contrário, é mock/simulado
        self.options = ccxt.binance({
            'apiKey': self.api_key,
            'secret': self.api_secret,
            'enableRateLimit': True,
            'options': {'defaultType': 'option'}
        })
        self._load_all_markets()

    def _load_all_markets(self):
        try:
            self.spot.load_markets()
            self.futures.load_markets()
            self.options.load_markets()
        except Exception as e:
            log_event({"acao": "erro_load_markets", "erro": str(e)})

    def executar_ordem(self, par, side, amount, type="market"):
        """
        Executa ordem spot real na Binance
        """
        try:
            if side == "buy":
                ordem = self.spot.create_market_buy_order(par, amount)
            else:
                ordem = self.spot.create_market_sell_order(par, amount)
            log_event({"acao": "exec_ordem_spot", "par": par, "side": side, "amount": amount, "retorno": ordem})
            return ordem
        except Exception as e:
            log_event({"acao": "erro_ordem_spot", "par": par, "side": side, "erro": str(e)})
            return {"erro": str(e)}

    def executar_ordem_futures(self, par, side, amount, leverage=1, reduce_only=False):
        """
        Executa ordem de futuros real na Binance.
        """
        try:
            self.futures.set_leverage(leverage, par.replace("/", ""))
            params = {'reduceOnly': reduce_only}
            if side == "buy":
                ordem = self.futures.create_market_buy_order(par, amount, params)
            else:
                ordem = self.futures.create_market_sell_order(par, amount, params)
            log_event({"acao": "exec_ordem_futures", "par": par, "side": side, "leverage": leverage, "retorno": ordem})
            return ordem
        except Exception as e:
            log_event({"acao": "erro_ordem_futures", "par": par, "side": side, "erro": str(e)})
            return {"erro": str(e)}

    def comprar_put_otm(self, symbol, amount, strike_price, expiry):
        """
        (Mock) Compra opção PUT OTM como hedge.  
        Integrar opção real via Deribit/Binance Option conforme disponível.
        """
        # Se quiser real, adapte com a exchange Deribit ou Binance se habilitado!
        try:
            res = {
                "status": "enviado",
                "msg": "Ordem PUT OTM mock (simulada).",
                "symbol": symbol,
                "amount": amount,
                "strike": strike_price,
                "expiry": expiry
            }
            log_event({"acao": "hedge_put_otm", "detalhes": res})
            return res
        except Exception as e:
            log_event({"acao": "erro_hedge_put_otm", "erro": str(e)})
            return {"erro": str(e)}

    def executar_opostas(self, ordens):
        """
        Executa múltiplas ordens diferentes: spot, future, option.
        ordens: lista de dicts (cada dict precisa de keys: tipo, par, side, amount, [strike], [expiry])
        """
        resultados = []
        for ordem in ordens:
            try:
                if ordem.get("tipo") == "future":
                    r = self.executar_ordem_futures(
                        ordem["par"], ordem["side"], ordem["amount"],
                        leverage=ordem.get("leverage", 1),
                        reduce_only=ordem.get("reduce_only", False)
                    )
                elif ordem.get("tipo") == "option":
                    r = self.comprar_put_otm(
                        ordem["par"], ordem["amount"], ordem.get("strike"), ordem.get("expiry")
                    )
                else:
                    r = self.executar_ordem(
                        ordem["par"], ordem["side"], ordem["amount"]
                    )
                resultados.append(r)
            except Exception as e:
                resultados.append({"erro": str(e), "ordem": ordem})
        log_event({"acao": "exec_opostas", "ordens": ordens, "resultados": resultados})
        return resultados

    def checar_saldo(self, moeda="USDT"):
        """
        Consulta saldo disponível para uma moeda
        """
        try:
            saldo = self.spot.fetch_balance()
            valor = saldo['free'].get(moeda, 0.0)
            log_event({"acao": "checar_saldo", "moeda": moeda, "valor": valor})
            return valor
        except Exception as e:
            log_event({"acao": "erro_saldo", "erro": str(e)})
            return 0.0

    def checar_ordens_abertas(self, par):
        """
        Lista ordens abertas para o par selecionado.
        """
        try:
            ordens = self.spot.fetch_open_orders(par)
            log_event({"acao": "checar_ordens_abertas", "par": par, "qtd": len(ordens)})
            return ordens
        except Exception as e:
            log_event({"acao": "erro_ordens_abertas", "erro": str(e)})
            return []

    def cancelar_ordem(self, par, order_id):
        """
        Cancela ordem aberta
        """
        try:
            retorno = self.spot.cancel_order(order_id, par)
            log_event({"acao": "cancelar_ordem", "par": par, "order_id": order_id, "retorno": retorno})
            return retorno
        except Exception as e:
            log_event({"acao": "erro_cancelar_ordem", "erro": str(e)})
            return {"erro": str(e)}

    # Adicione mais métodos para Withdraw, OCO, Trailing, etc, conforme necessidade!

# Permite testar diretamente
if __name__ == "__main__":
    ex = BinanceExecutor()
    print(ex.checar_saldo())
