import json
import os
from datetime import datetime

LOG_PATH = "data/logs/log_auditoria.txt"

def log_event(evento, nivel="INFO"):
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    registro = {
        "timestamp": datetime.now().isoformat(),
        "nivel": nivel,
        "evento": evento
    }
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(registro, ensure_ascii=False) + "\n")

def buscar_logs(ultimos=100, nivel=None):
    if not os.path.exists(LOG_PATH):
        return []
    with open(LOG_PATH, "r", encoding="utf-8") as f:
        linhas = f.readlines()[-ultimos:]
    logs = [json.loads(l) for l in linhas]
    if nivel:
        logs = [l for l in logs if l.get("nivel") == nivel]
    return logs
