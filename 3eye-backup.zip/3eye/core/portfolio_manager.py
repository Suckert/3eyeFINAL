from core.logger_auditoria import log_event

class CarteiraDinamicaIA:
    """
    Carteira Dinâmica IA: faz alocação e execução inteligente entre ativos e estratégias
    - Score dinâmico determina capital para cada par/estratégia
    - Log completo para auditoria
    - Suporte para hedge, supremo_ia, copytrade, etc
    """
    def __init__(self, binance_executor, saldo_total=10000, verbose=True):
        self.executor = binance_executor
        self.ativos = ["BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT"]
        self.estrategias = ["supremo_ia", "hedge", "copytrade"]
        self.saldo_total = saldo_total
        self.verbose = verbose

    def alocar_dinamico(self, score_dict):
        """
        Distribui capital proporcional aos scores entre pares/estratégias.
        score_dict: dict {("BTC/USDT", "supremo_ia"): 0.8, ...}
        Retorna: lista de dicts [{par, estrategia, capital, side}]
        """
        alocacoes = []
        total = sum(abs(v) for v in score_dict.values())
        if total == 0:
            log_event({"acao": "alocacao_dinamica", "status": "score_total_zero"})
            return alocacoes

        for key, v in score_dict.items():
            par, strat = key
            if par not in self.ativos or strat not in self.estrategias:
                if self.verbose:
                    print(f"Pulando alocação inválida: {par}/{strat}")
                continue
            capital = self.saldo_total * abs(v) / total
            side = "buy" if v >= 0 else "sell"
            alocacoes.append({
                "par": par,
                "estrategia": strat,
                "capital": capital,
                "side": side
            })
        log_event({"acao": "alocacao_dinamica", "alocacoes": alocacoes})
        return alocacoes

    def executar_alocacao(self, alocacoes):
        """
        Executa ordens conforme as alocações: hedge, futuro, spot.
        Retorna lista de resultados.
        """
        resultados = []
        for aloc in alocacoes:
            try:
                if aloc["estrategia"] == "hedge":
                    # Pode calibrar strike/expiry conforme volatilidade real
                    strike = 0  # Real: calcular strike OTM (ex: 2% abaixo do preço spot)
                    r = self.executor.comprar_put_otm(
                        aloc["par"], aloc["capital"] / 100, strike_price=strike, expiry="1w"
                    )
                elif aloc["estrategia"] == "supremo_ia":
                    r = self.executor.executar_ordem_futures(
                        aloc["par"], aloc["side"], aloc["capital"] / 100
                    )
                else:  # copytrade ou spot default
                    r = self.executor.executar_ordem(
                        aloc["par"], aloc["side"], aloc["capital"] / 100
                    )
                resultados.append({"aloc": aloc, "resultado": r})
            except Exception as e:
                log_event({"acao": "erro_exec_aloc", "aloc": aloc, "erro": str(e)})
                resultados.append({"aloc": aloc, "erro": str(e)})
        log_event({"acao": "exec_aloc_dinamica", "resultados": resultados})
        return resultados

    def saldo_atual(self, moeda="USDT"):
        """
        Consulta saldo atual (default USDT).
        """
        return self.executor.checar_saldo(moeda)

    def atualizar_ativos_estrategias(self, ativos=None, estrategias=None):
        """
        Atualiza lista de ativos e estratégias permitidos.
        """
        if ativos:
            self.ativos = ativos
        if estrategias:
            self.estrategias = estrategias
        log_event({"acao": "atualizar_ativos_estrategias", "ativos": self.ativos, "estrategias": self.estrategias})

    def resumo(self):
        """
        Exibe resumo para painel/monitor.
        """
        print(f"Carteira Dinâmica — Ativos: {self.ativos} | Estratégias: {self.estrategias} | Saldo: {self.saldo_total}")

# Uso:
# executor = BinanceExecutor()
# carteira = CarteiraDinamicaIA(executor)
# scores = {("BTC/USDT","supremo_ia"): 0.8, ("ETH/USDT","hedge"):0.6}
# aloc = carteira.alocar_dinamico(scores)
# carteira.executar_alocacao(aloc)
