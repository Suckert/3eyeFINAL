from datetime import datetime

class Governance:
    def __init__(self, perfil, auditoria=None):
        self.perfil = perfil
        self.auditoria = auditoria if auditoria else lambda x: None

    def pode_operar(self, risco, valor_ordem, motivo=None):
        # Defina regras de limites por perfil e horário operacional
        limites = {
            "3eye": {"risco": 0.15, "min": 10, "max": 5000},
            "Multiplicação Divina": {"risco": 0.25, "min": 20, "max": 10000},
            "Gestor Quant": {"risco": 0.10, "min": 10, "max": 3000},
            "Conservador": {"risco": 0.07, "min": 10, "max": 1500},
            "Agressivo": {"risco": 0.30, "min": 10, "max": 20000},
            "IA Total": {"risco": 0.50, "min": 10, "max": 100000}
        }
        lim = limites.get(self.perfil, limites["Gestor Quant"])
        hora = datetime.now().hour
        # Regras de horários: impedir trades fora do expediente, exceto IA Total
        if self.perfil != "IA Total" and not (8 <= hora <= 23):
            self.auditoria(f"Negado: operação fora do horário permitido para {self.perfil}")
            return False, "Operação não permitida fora do horário (8h-23h)"
        if risco > lim["risco"]:
            self.auditoria(f"Negado: risco {risco:.2f} excede limite do perfil {self.perfil} ({lim['risco']:.2f})")
            return False, f"Risco {risco:.2f} excede limite do perfil ({lim['risco']:.2f})"
        if valor_ordem < lim["min"]:
            self.auditoria(f"Negado: ordem {valor_ordem} abaixo do mínimo {lim['min']}")
            return False, f"Ordem menor que valor mínimo permitido ({lim['min']})"
        if valor_ordem > lim["max"]:
            self.auditoria(f"Negado: ordem {valor_ordem} acima do máximo {lim['max']}")
            return False, f"Ordem maior que valor máximo permitido ({lim['max']})"
        self.auditoria(f"Aprovado: perfil {self.perfil}, risco {risco}, valor {valor_ordem}, motivo: {motivo}")
        return True, "Ordem aprovada"
