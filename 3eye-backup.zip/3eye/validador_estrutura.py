import os

ARQUIVOS_OBRIGATORIOS = [
    "app.py", ".env", "requirements.txt", "3eye_selector.bat", "README_MANUAL.md",
    "core/binance_exec_supremo.py", "core/portfolio_manager.py", "core/governance.py",
    "core/logger_auditoria.py", "core/backup_module.py", "core/config_manager.py",
    "modules/ml_supremo.py", "modules/sentiment_supremo.py", "modules/rebalanceador_supremo.py",
    "modules/arbitrage.py", "modules/risk_engine.py", "modules/feature_engine.py",
    "modules/hedge.py", "modules/news_trading.py", "modules/stop_manager.py",
    "modules/score_engine.py", "modules/walk_forward.py", "modules/utils.py",
    "ui/side_menu.py", "ui/charts.py", "ui/dashboard_supremo.py", "ui/dashboard_apple.py",
    "ui/dashboard_quantum.py", "ui/dashboard_dazarabia.py", "ui/dashboard_lab.py",
    "ui/onboarding.py", "ui/painel_auditoria.py", "ui/config_advanced.py",
    "plugins/supremo_ia.py", "plugins/copytrade.py", "plugins/scalping.py", "plugins/hedge.py", "plugins/hist_supremo_ia.csv",
    "export/export_tools.py", "export/templates/excel_base.xlsx",
    "data/logs/log_auditoria.txt", "data/backups/", "data/configs/supremo_config.json",
    "webhooks.py", "sinais_webhook.txt", "sinais_discord.txt", "sinais_externos.txt"
]

def valida_estrutura():
    print("\nCHECKLIST 3EYE SUPREMO\n========================")
    faltando = False
    for caminho in ARQUIVOS_OBRIGATORIOS:
        if os.path.isdir(caminho) or os.path.isfile(caminho):
            print(f"\033[92m✔ OK:\033[0m {caminho}")
        else:
            print(f"\033[91m✖ FALTANDO:\033[0m {caminho}")
            faltando = True
    if faltando:
        print("\nAtenção! Existem arquivos ou pastas faltando. Crie-os conforme o checklist.")
    else:
        print("\nTudo OK! Sistema pronto para rodar em modo SUPREMO.")

if __name__ == "__main__":
    valida_estrutura()
