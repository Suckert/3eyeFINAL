import importlib
import traceback

def testar_func(modulo, funcao, args=(), kwargs=None):
    try:
        m = importlib.import_module(modulo)
        f = getattr(m, funcao)
        resultado = f(*args, **(kwargs or {}))
        print(f"[PASS] {modulo}.{funcao} — Resultado: {str(resultado)[:60]}")
        return True
    except Exception as e:
        print(f"[FAIL] {modulo}.{funcao} — Erro: {e}")
        traceback.print_exc()
        return False

def main():
    print("========== TESTE AUTOMATIZADO DE EXECUÇÃO ==========")
    # Testar painéis (simula execução das funções principais)
    PAINEIS = [
        ("ui.painel_supremo", "painel_supremo", ()),
        ("ui.dashboard_apple", "main_dashboard", ()),
        ("ui.dashboard_quantum", "main_dashboard", ()),
        ("ui.dashboard_dazarabia", "main_dashboard", ()),
        ("ui.dashboard_lab", "main_dashboard", ()),
        ("ui.painel_auditoria", "painel_auditoria", ()),
        ("ui.config_advanced", "painel_config_advanced", ()),
        ("ui.risk_dashboard", "risk_dashboard", (None,)),  # df=None mock
    ]
    for m, f, args in PAINEIS:
        testar_func(m, f, args)
    # Testar plugins
    PLUGINS = [
        ("plugins.supremo_ia", "executar", (None,)),  # None como mock de df/executor
        ("plugins.copytrade", "executar", ([], None)),
        ("plugins.scalping", "executar", (None,)),
        ("plugins.arbitrage", "executar", ([], None)),
        ("plugins.hedge", "executar", (None,)),
    ]
    for m, f, args in PLUGINS:
        testar_func(m, f, args)
    # Testar core
    CORE = [
        ("core.logger_auditoria", "log_event", ("Teste de log",)),
        ("core.backup_scheduler", "criar_backup", ()),
    ]
    for m, f, args in CORE:
        testar_func(m, f, args)
    print("========== FIM DOS TESTES ==========")

if __name__ == "__main__":
    main()
