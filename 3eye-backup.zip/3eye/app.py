import streamlit as st
import sys
import os

# --- Importação dinâmica segura e robusta ---
from ui.side_menu import super_sidebar
from modules.utils import ler_logs_rapidos, listar_plugins
from ui.charts import show_heatmap, plot_walk_forward

# Mapeamento dos painéis e funções
PAINEL_OPCOES = {
    "supremo": "Painel Supremo",
    "apple": "Painel Apple Vision",
    "quantum": "Painel Quantum Cyber",
    "dazarabia": "Painel Dazarabia Lux",
    "lab": "Supreme LAB",
    "auditoria": "Painel de Auditoria",
    "config": "Configuração Avançada",
    "risco": "Painel de Risco"
}

PAINEL_FUNCOES = {
    "supremo": lambda: __import__('ui.painel_supremo', fromlist=['painel_supremo']).painel_supremo(),
    "apple": lambda: __import__('ui.dashboard_apple', fromlist=['main_dashboard']).main_dashboard("Apple Vision"),
    "quantum": lambda: __import__('ui.dashboard_quantum', fromlist=['main_dashboard']).main_dashboard("Quantum Cyber"),
    "dazarabia": lambda: __import__('ui.dashboard_dazarabia', fromlist=['main_dashboard']).main_dashboard("Dazarabia Lux"),
    "lab": lambda: __import__('ui.dashboard_lab', fromlist=['main_dashboard']).main_dashboard("LAB"),
    "auditoria": lambda: __import__('ui.painel_auditoria', fromlist=['painel_auditoria']).painel_auditoria(),
    "config": lambda: __import__('ui.config_advanced', fromlist=['painel_config_advanced']).painel_config_advanced(),
    "risco": lambda: __import__('ui.risk_dashboard', fromlist=['risk_dashboard']).risk_dashboard(),
}

# Detecta painel inicial por argumento
painel_inicial = "supremo"
if "--painel" in sys.argv:
    idx = sys.argv.index("--painel")
    if idx + 1 < len(sys.argv):
        painel_inicial = sys.argv[idx + 1].lower()

if "painel" not in st.session_state:
    st.session_state["painel"] = painel_inicial

# Sidebar global visual e tecnológico
super_sidebar()

# Cabeçalho visual
painel_nome = PAINEL_OPCOES.get(st.session_state["painel"], "Painel")
st.title(f"{painel_nome} — 3EYE SUPREMO")

# Loader dinâmico do painel
if st.session_state["painel"] in PAINEL_FUNCOES:
    try:
        PAINEL_FUNCOES[st.session_state["painel"]]()
    except Exception as e:
        st.error(f"Erro ao carregar o painel '{painel_nome}': {e}")
else:
    st.warning(f"Painel '{st.session_state['painel']}' não encontrado!")

# Ferramentas avançadas (logs, heatmap, walk-forward, plugins)
with st.expander("📝 Logs Recentes (10 últimos)", expanded=False):
    logs = ler_logs_rapidos(10)
    for log in logs:
        st.code(log, language="json" if log.startswith("{") else "text")

with st.expander("🔥 Heatmap de Performance & Walk-Forward", expanded=False):
    st.write("Heatmap global das estratégias:")
    show_heatmap()
    st.write("Análise Walk-Forward real:")
    plot_walk_forward()

with st.expander("🔌 Plug-ins ativos no sistema", expanded=False):
    st.write("Plug-ins disponíveis:", listar_plugins())

st.caption("Powered by 3EYE SUPREMO — Todos os direitos reservados — Multiplicação Inteligente")

# CSS Visual (opcional)
st.markdown("""
<style>
[data-testid="stSidebar"] { background: linear-gradient(180deg,#181818 60%,#1e2746 100%); }
.main { background-color: #131313 !important; color: #e7e7e7 !important; }
</style>
""", unsafe_allow_html=True)
