from core.logger_auditoria import log_event

def executar(df, executor):
    # Sinal IA: compra se média móvel curta cruzou acima longa
    sinais = []
    df['ma5'] = df['close'].rolling(5).mean().fillna(method='bfill')
    df['ma20'] = df['close'].rolling(20).mean().fillna(method='bfill')
    for i in range(20, len(df)):
        if df['ma5'][i-1] < df['ma20'][i-1] and df['ma5'][i] > df['ma20'][i]:
            resp = executor.executar_ordem("BTC/USDT", "buy", 0.01)
            sinais.append({"timestamp": df.index[i], "side":"buy", "resultado":resp})
        elif df['ma5'][i-1] > df['ma20'][i-1] and df['ma5'][i] < df['ma20'][i]:
            resp = executor.executar_ordem("BTC/USDT", "sell", 0.01)
            sinais.append({"timestamp": df.index[i], "side":"sell", "resultado":resp})
    log_event({"acao":"supremo_ia_exec","sinais":sinais})
    return sinais
