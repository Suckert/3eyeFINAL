from core.logger_auditoria import log_event
import time

def executar(sinais, executor, delay=0.5):
    """
    Executa sinais de copytrade. Aprova apenas sinais de score adequado.
    """
    resultados = []
    for sinal in sinais:
        aprovado, msg = True, "OK"
        if sinal.get("score", 0) < 0.1:
            aprovado, msg = False, "Sinal com score baixo"
        if aprovado:
            try:
                res = executor.executar_ordem(sinal["par"], sinal["acao"], sinal["quantidade"])
                log_event({"acao":"copytrade_exec", "sinal": sinal, "resultado": res})
                resultados.append({"par": sinal["par"], "acao": sinal["acao"], "executado": True, "detalhes":res})
            except Exception as e:
                resultados.append({"par": sinal["par"], "acao": sinal["acao"], "executado": False, "erro":str(e)})
        else:
            resultados.append({"par": sinal["par"], "acao": sinal["acao"], "executado": False, "motivo": msg})
        time.sleep(delay)
    return resultados

def treinar(_):
    # Pode calibrar delay, score mínimo, blacklist, etc
    pass
