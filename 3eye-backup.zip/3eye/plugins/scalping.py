from core.logger_auditoria import log_event

def executar(df, executor=None, par="BTC/USDT", stop=0.1):
    """
    Estratégia scalping simples: compra quando variação sobe rápido, vende quando cai.
    """
    resultados = []
    for i in range(2, len(df)):
        delta = df['close'][i] - df['close'][i-1]
        if delta > stop:
            res = executor.executar_ordem(par, "buy", 0.01) if executor else {"msg":"exec mock"}
            log_event({"acao": "scalping_compra", "par": par, "delta": delta})
            resultados.append({"timestamp": df.index[i], "compra": True, "detalhes": res})
        elif delta < -stop:
            res = executor.executar_ordem(par, "sell", 0.01) if executor else {"msg":"exec mock"}
            log_event({"acao": "scalping_venda", "par": par, "delta": delta})
            resultados.append({"timestamp": df.index[i], "venda": True, "detalhes": res})
        else:
            resultados.append({"timestamp": df.index[i], "inativo": True, "delta": delta})
    return resultados

def treinar(_):
    # Pode calibrar stop ou ativos
    pass
