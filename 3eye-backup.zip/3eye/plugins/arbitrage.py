from core.logger_auditoria import log_event

def executar(ativos, executor):
    """
    Executa arbitragem entre pares. 
    Busca oportunidade de spread entre bid e ask em tempo real.
    """
    resultados = []
    for par in ativos:
        try:
            book = executor.spot.fetch_order_book(par)
            bid = book['bids'][0][0]
            ask = book['asks'][0][0]
            spread = bid - ask
            if spread > 0.01:  # threshold de arbitragem
                log_event({"acao": "arbitragem", "par": par, "spread": spread})
                resultados.append({"par": par, "spread": spread, "status": "exec"})
            else:
                resultados.append({"par": par, "spread": spread, "status": "sem_op"})
        except Exception as e:
            resultados.append({"par": par, "erro": str(e)})
    return resultados

def treinar(_):
    # Pode calibrar thresholds ou pares preferidos
    pass
