from fastapi import FastAPI, Request

app = FastAPI()

@app.post("/webhook/sinal")
async def receber_sinal(request: Request):
    data = await request.json()
    with open("sinais_externos.txt", "a") as f:
        f.write(str(data)+"\n")
    return {"status": "ok"}
# Rode com: uvicorn webhooks:app --reload
