import os
import json
import pandas as pd
from core.logger_auditoria import log_event

HIST_PATH = "data/logs/hist_rebalance.json"

class Rebalanceador:
    def __init__(self, persist_hist=True):
        self.historico = []
        self.persist_hist = persist_hist
        if persist_hist:
            self._carregar_historico()

    def _carregar_historico(self):
        if os.path.exists(HIST_PATH):
            try:
                with open(HIST_PATH, "r", encoding="utf-8") as f:
                    self.historico = json.load(f)
            except Exception:
                self.historico = []

    def _salvar_historico(self):
        if self.persist_hist:
            os.makedirs(os.path.dirname(HIST_PATH), exist_ok=True)
            with open(HIST_PATH, "w", encoding="utf-8") as f:
                json.dump(self.historico, f, ensure_ascii=False, indent=2)

    def calcular_alocacao(self, perfil, regime, score_ativos):
        aloc = {}
        total_score = sum(score_ativos.values())
        fator_perfil = {
            "Conservador (Risco Baixo)": 0.8,
            "Moderado": 1,
            "Agressivo": 1.2,
            "IA Inteligente": 1.0,
            "SUPREMO IA-Alavancada": 1.4,
            "3eye": 1.33,
            "Multiplicação Divina": 2.0,
        }
        for ativo, score in score_ativos.items():
            base = (score / total_score) if total_score else 1 / len(score_ativos)
            fator = fator_perfil.get(perfil, 1.0)
            aloc[ativo] = base * fator
        log_event({"acao": "calculo_alocacao", "perfil": perfil, "regime": regime,
                   "score_ativos": score_ativos, "alocacao": aloc})
        return aloc

    def rebalancear(self, carteira, alocacao, executor):
        transacoes = []
        for ativo, perc_alvo in alocacao.items():
            valor_total = carteira['quantidade'].sum()
            quantidade_alvo = perc_alvo * valor_total
            atual = carteira.loc[carteira['ativo'] == ativo, 'quantidade'].sum()
            diff = quantidade_alvo - atual
            if abs(diff) > 1e-6:
                side = "buy" if diff > 0 else "sell"
                # executor.executar_ordem(f"{ativo}/USDT", side, abs(diff))
                transacoes.append({"ativo": ativo, "side": side, "quantidade": abs(diff)})
        self.historico.append({"rebalanceamento": transacoes, "alocacao": alocacao})
        self._salvar_historico()
        log_event({"acao": "rebalanceamento_exec", "transacoes": transacoes, "alocacao": alocacao})
        return transacoes
