import json
import requests
from core.logger_auditoria import log_event

def get_plugin_history(plugin_name):
    """
    Busca o histórico do plug-in (implemente acesso real ao log/auditoria do plugin, se houver).
    """
    try:
        with open(f"data/logs/{plugin_name}_history.json", "r", encoding="utf-8") as f:
            history = json.load(f)
        return history
    except Exception:
        return []

def ler_logs_rapidos(n=30, nivel=None):
    try:
        with open("data/logs/log_auditoria.txt", "r", encoding="utf-8") as f:
            lines = f.readlines()[-n:]
        eventos = [json.loads(l) for l in lines]
        if nivel:
            eventos = [e for e in eventos if e.get("nivel") == nivel]
        return [e["evento"] for e in eventos]
    except Exception as e:
        log_event(f"Erro ao ler logs rápidos: {e}", nivel="ERROR")
        return []

def autoexec_best_plugins():
    """
    Executa automaticamente os melhores plug-ins baseados em score, para o modo IA-Auto.
    """
    from plugins.supremo_ia import executar
    import pandas as pd
    import numpy as np
    df = pd.DataFrame({"close": 100 + np.cumsum(np.random.randn(10))})
    resultados = executar(df)
    log_event({"acao": "autoexec_supremo_ia", "resultados": resultados})

def enviar_alerta_telegram(msg, token=None, chat_id=None):
    """
    Envia alertas críticos para Telegram.
    """
    if not token or not chat_id:
        return False
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {"chat_id": chat_id, "text": msg}
    try:
        r = requests.post(url, data=payload)
        if r.status_code == 200:
            log_event(f"Alerta Telegram enviado: {msg}", nivel="ALERTA")
            return True
        else:
            log_event(f"Falha Telegram: {r.text}", nivel="ERROR")
            return False
    except Exception as e:
        log_event(f"Erro Telegram: {e}", nivel="ERROR")
        return False
# utils.py (adicione isso AO FINAL DO ARQUIVO)

import os
import json

def get_plugin_history(plugin, maxlen=20):
    """
    Busca histórico de execuções/resultados de um plugin.
    Exemplo: carrega logs ou resultados salvos do plugin.
    """
    log_path = f"data/logs/{plugin}_history.json"
    if not os.path.exists(log_path):
        return [], []
    try:
        with open(log_path, "r", encoding="utf-8") as f:
            historico = json.load(f)
        # Supondo que salva uma lista de números ou dicts:
        resultados = [h.get("result", 0) if isinstance(h, dict) else h for h in historico]
        datas = [h.get("timestamp", "") if isinstance(h, dict) else "" for h in historico]
        return resultados[-maxlen:], datas[-maxlen:]
    except Exception as e:
        return [], []