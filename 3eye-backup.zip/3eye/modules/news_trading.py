import requests
from core.logger_auditoria import log_event

class OlhoDeSalomao:
    def __init__(self, news_api_key):
        self.api_key = news_api_key

    def get_news(self, query="bitcoin OR crypto OR ethereum", max_articles=5):
        url = f"https://newsapi.org/v2/everything?q={query}&apiKey={self.api_key}&pageSize={max_articles}&sortBy=publishedAt"
        r = requests.get(url)
        artigos = r.json().get("articles", [])
        noticias = [{"title":a["title"], "description":a["description"], "date":a["publishedAt"]} for a in artigos]
        log_event({"acao":"get_news","noticias":noticias})
        return noticias

    def analisar_sentimento(self, noticias):
        score = 0
        for n in noticias:
            if any(p in n["title"].lower() for p in ["cai", "queda", "baixa", "crash", "venda", "bear"]):
                score -= 1
            elif any(p in n["title"].lower() for p in ["sobe", "alta", "lucro", "bull", "compra", "recorde"]):
                score += 1
        resultado = score / (len(noticias) or 1)
        log_event({"acao":"sentimento_news","score":resultado,"noticias":noticias})
        return resultado

    def score_noticia_ativos(self, ativos):
        noticias = self.get_news()
        sent = self.analisar_sentimento(noticias)
        return {a: sent for a in ativos}
