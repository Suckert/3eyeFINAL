import numpy as np
import pandas as pd
from core.logger_auditoria import log_event

class ScoreEngine:
    """
    Calcula score global dos ativos, usando retorno, volume, sentimento, plug-ins e notícias.
    Suporta aprendizado por reforço, recalibração dinâmica e auditoria de pesos.
    """

    def __init__(self, pesos=None):
        self.pesos = pesos or {
            "retorno": 0.35,
            "volume": 0.15,
            "sentimento": 0.1,
            "plugin": 0.2,
            "noticia": 0.2
        }
        self.memoria = {}  # {ativo: [resultados passados]}
        self.historico_score = []

    def update_reforco(self, resultado_ciclo):
        """
        Atualiza a memória do ciclo passado para reforço/aprendizado.
        """
        for k, v in resultado_ciclo.items():
            if k in self.memoria:
                self.memoria[k].append(v)
                if len(self.memoria[k]) > 100:
                    self.memoria[k] = self.memoria[k][-100:]
            else:
                self.memoria[k] = [v]
        log_event({"acao": "update_reforco", "memoria": self.memoria})

    def recalibrar(self, ultimos_resultados, plugin_results, noticia_score, auto=True):
        """
        Recalibra pesos dos fatores (ajuste automático por Sharpe, plugins, notícias).
        """
        sharpe = ultimos_resultados.get("sharpe", 1) if ultimos_resultados else 1
        plugin_score = np.mean([v for v in plugin_results.values() if v]) if plugin_results else 0.2
        noticia_avg = np.mean([v for v in noticia_score.values() if v]) if noticia_score else 0.1

        if auto:
            self.pesos["plugin"] = min(0.4, max(0.1, 0.2 + 0.1 * plugin_score))
            self.pesos["noticia"] = min(0.3, max(0.05, noticia_avg * 0.3))
            self.pesos["retorno"] = max(0.2, min(0.5, sharpe * 0.3))
        log_event({"acao": "recalibrar_pesos", "pesos": self.pesos})

    def calcular_score(self, retornos, volumes, sentimentos, plugin_hist=None, noticia=None):
        """
        Calcula score dos ativos. Todos os inputs são dict {ativo: valor}.
        O score é ponderado pelos pesos, e pode ser chamado a cada ciclo.
        """
        score = {}
        plugin_hist = plugin_hist or {}
        noticia = noticia or {}
        for ativo in retornos:
            p = plugin_hist.get(ativo, 0)
            n = noticia.get(ativo, 0)
            v = volumes.get(ativo, 0)
            sen = sentimentos.get(ativo, 0)
            s = (retornos[ativo] * self.pesos["retorno"] +
                 v * self.pesos["volume"] +
                 sen * self.pesos["sentimento"] +
                 p * self.pesos["plugin"] +
                 n * self.pesos["noticia"])
            score[ativo] = s
        # Salva no histórico e loga para auditoria
        self.historico_score.append({"score": score, "pesos": self.pesos, "timestamp": pd.Timestamp.now().isoformat()})
        log_event({"acao": "calculo_score", "score": score, "pesos": self.pesos})
        return score

    def exibir_historico(self, n=5):
        """Retorna últimos n cálculos de score para painel/auditoria."""
        return self.historico_score[-n:]

    def explicar(self):
        """Explicação dos fatores, para leigos/painel."""
        return {
            "retorno": "Ganho percentual esperado ou realizado do ativo.",
            "volume": "Volume negociado (liquidez) — sinaliza força do movimento.",
            "sentimento": "Sentimento de mercado — notícias, redes sociais, análise IA.",
            "plugin": "Performance dos plug-ins e estratégias automáticas.",
            "noticia": "Impacto de notícias ou eventos no ativo."
        }

    def exportar_historico(self, caminho="data/logs/historico_score.csv"):
        """Exporta histórico de scores para análise externa."""
        df = pd.DataFrame(self.historico_score)
        df.to_csv(caminho, index=False)
        return caminho

# --- Uso exemplo:
# score_engine = ScoreEngine()
# score = score_engine.calcular_score(retornos, volumes, sentimentos, plugin_hist, noticia)
# score_engine.recalibrar(ultimos_resultados, plugin_results, noticia_score)
