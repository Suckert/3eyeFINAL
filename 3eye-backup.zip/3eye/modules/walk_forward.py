import pandas as pd
from sklearn.metrics import mean_squared_error

def walk_forward_analysis(data, plug_in_func, window_train=200, window_test=20):
    resultados = []
    for start in range(0, len(data) - window_train - window_test, window_test):
        train = data.iloc[start:start+window_train]
        test = data.iloc[start+window_train:start+window_train+window_test]
        plug_in_func.treinar(train)
        res = plug_in_func.executar(test)
        resultados.extend(res)
    df_result = pd.DataFrame(resultados)
    mse = mean_squared_error(df_result['y_true'], df_result['y_pred'])
    return df_result, mse
