import numpy as np
from core.logger_auditoria import log_event

class StopManager:
    """
    Gerencia stops, alvo e trailing stop dinâmico para o 3EYE SUPREMO.
    Suporta métricas de volatilidade, logs, ajuste automático e explicação para painel.
    """
    def __init__(self, min_stop=0.002, min_alvo=0.005):
        self.min_stop = min_stop  # Exemplo: 0.2%
        self.min_alvo = min_alvo
        self.historico = []

    def calcular_stop(self, candles):
        """Calcula stop dinâmico via ATR simples (desvio padrão dos últimos 14 fechamentos)"""
        closes = np.array([c[4] for c in candles])
        if len(closes) < 14:
            stop = self.min_stop
        else:
            atr = np.std(closes[-14:]) * 2
            stop = max(atr, self.min_stop)
        log_event({"acao": "calcular_stop", "stop": float(stop)})
        self.historico.append({"acao": "stop", "valor": float(stop)})
        return stop

    def calcular_alvo(self, candles):
        """Calcula alvo automático usando momentum dos últimos 20 candles"""
        closes = np.array([c[4] for c in candles])
        if len(closes) < 20:
            alvo = self.min_alvo
        else:
            alvo = (closes[-1] - closes[-20]) / 20 * 3
            alvo = max(alvo, self.min_alvo)
        log_event({"acao": "calcular_alvo", "alvo": float(alvo)})
        self.historico.append({"acao": "alvo", "valor": float(alvo)})
        return alvo

    def ajustar_trailing(self, candles):
        """Ajusta trailing stop conforme volatilidade dos últimos 10 candles"""
        closes = np.array([c[4] for c in candles])
        if len(closes) >= 10:
            vol = np.std(closes[-10:])
        else:
            vol = self.min_stop
        trailing = vol * 1.5
        log_event({"acao": "ajustar_trailing", "trailing": float(trailing)})
        self.historico.append({"acao": "trailing", "valor": float(trailing)})
        return trailing

    def exibir_historico(self, n=10):
        """Mostra últimos n ajustes para painel/auditoria"""
        return self.historico[-n:]

    def explicar(self):
        """Explica os termos e lógica para usuário leigo/painel"""
        return {
            "stop": "Valor de proteção automática em caso de movimento adverso. Calculado por volatilidade (ATR simplificado).",
            "alvo": "Objetivo de lucro baseado no momentum dos últimos candles.",
            "trailing": "Stop móvel: ajusta conforme volatilidade recente para proteger ganhos.",
        }
