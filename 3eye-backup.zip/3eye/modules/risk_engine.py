import numpy as np
import pandas as pd
from core.logger_auditoria import log_event

class RiskEngine:
    """
    Avaliação completa de risco da carteira e ativos: volatilidade, VAR, correlação, alertas.
    Gera logs e outputs para painéis e automação de hedge.
    """

    def __init__(self, limites=None, alerta_autohedge=True):
        # Thresholds customizáveis!
        self.limites = limites or {"var": 0.06, "vol": 0.12, "correl": 0.85}
        self.alerta_autohedge = alerta_autohedge
        self.historico = []

    def avaliar(self, df_preco, carteira, periodo_var=5):
        """
        Parâmetros:
        - df_preco: DataFrame, colunas = ativos, linhas = datas, valores = preço
        - carteira: DataFrame/dict, deve ter coluna 'ativo'
        - periodo_var: quantos dias considerar para VaR e volatilidade
        """
        volatilidade = df_preco.pct_change(periodo_var).std()
        var_dict = {}
        correlacoes = df_preco.pct_change(periodo_var).corr()
        alertas = []

        for ativo in carteira['ativo']:
            if ativo not in df_preco.columns:
                continue
            serie = df_preco[ativo].pct_change(periodo_var).dropna()
            # VaR paramétrico (percentil 5%)
            var = np.percentile(serie, 5)
            var_dict[ativo] = var

            if volatilidade[ativo] > self.limites['vol']:
                alertas.append(f"Volatilidade alta em {ativo}: {volatilidade[ativo]:.2%}")
            if var < -self.limites['var']:
                alertas.append(f"VAR crítico ({ativo}): {var:.2%}")

            # Alerta automático de hedge?
            if self.alerta_autohedge and (volatilidade[ativo] > self.limites['vol'] or var < -self.limites['var']):
                alertas.append(f"[HEDGE] Recomendar proteção em {ativo}")

        # Checa correlação entre ativos
        for a1 in df_preco.columns:
            for a2 in df_preco.columns:
                if a1 != a2 and correlacoes.loc[a1, a2] > self.limites['correl']:
                    alertas.append(f"Alta correlação entre {a1} e {a2} ({correlacoes.loc[a1,a2]:.2f}) — risco de exposição excessiva!")

        resultado = {
            "volatilidade": volatilidade.to_dict(),
            "var": var_dict,
            "correlacoes": correlacoes.to_dict(),
            "alertas": alertas
        }
        self.historico.append({"resultado": resultado, "timestamp": pd.Timestamp.now().isoformat()})
        log_event({"acao": "avaliacao_risco", **resultado})
        return resultado

    def resumo_risco(self, n=5):
        """Retorna os últimos n relatórios para painel/auditoria."""
        return self.historico[-n:]

    def heatmap(self, correlacoes):
        """Para painel visual — pode usar plotly, seaborn ou matplotlib para heatmap."""
        import matplotlib.pyplot as plt
        import seaborn as sns
        if isinstance(correlacoes, dict):
            correlacoes = pd.DataFrame(correlacoes)
        plt.figure(figsize=(8, 6))
        sns.heatmap(correlacoes, annot=True, cmap='coolwarm')
        plt.title("Mapa de Correlação dos Ativos")
        plt.show()

    def explicar(self):
        """Explica métricas para leigos, para integrar ao painel."""
        return {
            "volatilidade": "Desvio padrão dos retornos em N dias — quanto maior, mais o preço oscila.",
            "VaR": "Value at Risk: perda máxima esperada no pior cenário de 5% em N dias.",
            "correlação": "Variação de dois ativos em conjunto; >0.85 é arriscado em carteiras.",
            "alerta": "Mensagem de risco crítico, recomendação de hedge ou diversificação."
        }

# Uso exemplo:
# risk = RiskEngine()
# resultado = risk.avaliar(df_precos, carteira_df)
# risk.heatmap(resultado["correlacoes"])
