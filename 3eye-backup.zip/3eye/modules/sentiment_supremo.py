# sentiment_supremo.py - arquivo de sistema 3eye
import requests
from core.logger_auditoria import log_event

def sentimento_global(ativos):
    score = 0
    news_url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,binancecoin&vs_currencies=usd"
    try:
        r = requests.get(news_url)
        if r.status_code == 200:
            data = r.json()
            var = sum(data[c]["usd"] for c in data) / len(data)
            if var > 0:
                score += 1
            else:
                score -= 1
    except:
        pass
    resultado = {a: score for a in ativos}
    log_event({"acao":"sentimento_global","resultado":resultado})
    return resultado
