from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split, GridSearchCV
from core.logger_auditoria import log_event

class MLTrader:
    def __init__(self):
        self.rf = RandomForestClassifier()
        self.xgb = XGBClassifier()
    def treinar(self, X, y):
        params_rf = {"n_estimators": [100,200], "max_depth":[3,6,10]}
        params_xgb = {"n_estimators": [50,100], "max_depth":[3,6]}
        self.rf = GridSearchCV(RandomForestClassifier(), params_rf, cv=3).fit(X, y).best_estimator_
        self.xgb = GridSearchCV(XGBClassifier(), params_xgb, cv=3).fit(X, y).best_estimator_
        log_event({"acao":"ml_treinado","rf_params":self.rf.get_params(),"xgb_params":self.xgb.get_params()})
    def prever(self, X):
        score_rf = self.rf.predict_proba(X)[:,1]
        score_xgb = self.xgb.predict_proba(X)[:,1]
        score_final = 0.6*score_rf + 0.4*score_xgb
        log_event({"acao":"previsao_ml", "score_rf": score_rf.tolist(), "score_xgb": score_xgb.tolist(), "score_final": score_final.tolist()})
        return score_final
    def plug_in_predict(self, plugin_name, X):
        from utils import dynamic_import
        plugin = dynamic_import(plugin_name)
        if plugin:
            return plugin.run_ml(X)
        return None
