from core.logger_auditoria import log_event

def executar(df, executor, ativo="BTC/USDT", threshold=0.05, expiry="1w"):
    """
    Executa hedge dinâmico com PUT OTM se volatilidade passar do threshold.
    Parâmetros:
        df: DataFrame de candles (deve ter coluna 'close' e index datetime)
        executor: objeto com método comprar_put_otm
        ativo: string do ativo (ex: BTC/USDT)
        threshold: percentual mínimo de volatilidade para hedge (ex: 0.05 == 5%)
        expiry: expiração da opção hedge (ex: '1w')
    Retorna:
        Lista de execuções com resultados detalhados.
    """
    resultados = []
    if df is None or len(df) < 2:
        log_event({"acao": "hedge_skip", "motivo": "df vazio ou curto", "ativo": ativo})
        return resultados

    for i in range(1, len(df)):
        close_now = df['close'].iloc[i]
        close_prev = df['close'].iloc[i - 1]
        timestamp = df.index[i] if hasattr(df.index, '__getitem__') else i
        volatilidade = abs(close_now - close_prev) / close_prev

        if volatilidade > threshold:
            try:
                # Executa hedge real/simulado
                res = executor.comprar_put_otm(
                    ativo=ativo, 
                    amount=0.01, 
                    strike_price=round(close_now * 0.98, 2), 
                    expiry=expiry
                )
                log_event({
                    "acao": "hedge_exec",
                    "ativo": ativo,
                    "timestamp": str(timestamp),
                    "volatilidade": volatilidade,
                    "strike_price": round(close_now * 0.98, 2),
                    "detalhes": res
                })
                resultados.append({
                    "timestamp": timestamp,
                    "hedge_ativo": True,
                    "volatilidade": volatilidade,
                    "strike": round(close_now * 0.98, 2),
                    "detalhes": res
                })
            except Exception as e:
                log_event({
                    "acao": "hedge_fail",
                    "ativo": ativo,
                    "timestamp": str(timestamp),
                    "volatilidade": volatilidade,
                    "erro": str(e)
                })
                resultados.append({
                    "timestamp": timestamp,
                    "hedge_ativo": False,
                    "volatilidade": volatilidade,
                    "erro": str(e)
                })
        else:
            resultados.append({
                "timestamp": timestamp,
                "hedge_ativo": False,
                "volatilidade": volatilidade
            })
    return resultados

def treinar(df, target="volatilidade"):
    """
    (Opcional) Treina parâmetros ótimos de hedge:
    Exemplo: descobre melhor threshold, expiry, tamanho do hedge, etc.
    """
    # Implementar otimização futura, se desejar.
    return None
